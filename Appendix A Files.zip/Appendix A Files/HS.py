# Calculation for velocity potential at point (x,y,z) due to unit source density distribution on quadrilateral panel with vertices (x1,y1), (x2,y2),
# (x3,y3), and (x4,y4) based on analytical formulation in p. 54 of the paper by Hess and Smith (1967): Calculation of Potential Flow About Arbitrary Bodies.

import numpy as np
import math

x=-0
y=0
z=-25

x1=-2.5
y1=-2.5

x2=-2.5
y2=2.5

x3=2.5
y3=2.5

x4=2.5
y4=-2.5

d12=np.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1))
d23=np.sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2))
d34=np.sqrt((x4-x3)*(x4-x3)+(y4-y3)*(y4-y3))
d41=np.sqrt((x1-x4)*(x1-x4)+(y1-y4)*(y1-y4))

r1=np.sqrt((x-x1)*(x-x1)+(y-y1)*(y-y1)+z*z)
r2=np.sqrt((x-x2)*(x-x2)+(y-y2)*(y-y2)+z*z)
r3=np.sqrt((x-x3)*(x-x3)+(y-y3)*(y-y3)+z*z)
r4=np.sqrt((x-x4)*(x-x4)+(y-y4)*(y-y4)+z*z)

C12=(x2-x1)/d12
C23=(x3-x2)/d23
C34=(x4-x3)/d34
C41=(x1-x4)/d41

S12=(y2-y1)/d12
S23=(y3-y2)/d23
S34=(y4-y3)/d34
S41=(y1-y4)/d41

s12_1=(x1-x)*C12+(y1-y)*S12
s12_2=(x2-x)*C12+(y2-y)*S12
s23_1=(x2-x)*C23+(y2-y)*S23
s23_2=(x3-x)*C23+(y3-y)*S23
s34_1=(x3-x)*C34+(y3-y)*S34
s34_2=(x4-x)*C34+(y4-y)*S34
s41_1=(x4-x)*C41+(y4-y)*S41
s41_2=(x1-x)*C41+(y1-y)*S41

R12=(x-x1)*S12-(y-y1)*C12
R23=(x-x2)*S23-(y-y2)*C23
R34=(x-x3)*S34-(y-y3)*C34
R41=(x-x4)*S41-(y-y4)*C41

Q12=math.log((r1+r2+d12)/(r1+r2-d12))
Q23=math.log((r2+r3+d23)/(r2+r3-d23))
Q34=math.log((r3+r4+d34)/(r3+r4-d34))
Q41=math.log((r4+r1+d41)/(r4+r1-d41))

J12_n=R12*abs(z)*(r1*s12_2-r2*s12_1)
J12_d=r1*r2*R12*R12+z*z*s12_2*s12_1

J23_n=R23*abs(z)*(r2*s23_2-r3*s23_1)
J23_d=r2*r3*R23*R23+z*z*s23_2*s23_1

J34_n=R34*abs(z)*(r3*s34_2-r4*s34_1)
J34_d=r3*r4*R34*R34+z*z*s34_2*s34_1

J41_n=R41*abs(z)*(r4*s41_2-r1*s41_1)
J41_d=r4*r1*R41*R41+z*z*s41_2*s41_1


J12=np.arctan2(R12*abs(z)*(r1*s12_2-r2*s12_1),(r1*r2*R12*R12+z*z*s12_2*s12_1))
J23=np.arctan2(R23*abs(z)*(r2*s23_2-r3*s23_1),(r2*r3*R23*R23+z*z*s23_2*s23_1))
J34=np.arctan2(R34*abs(z)*(r3*s34_2-r4*s34_1),(r3*r4*R34*R34+z*z*s34_2*s34_1))
J41=np.arctan2(R41*abs(z)*(r4*s41_2-r1*s41_1),(r4*r1*R41*R41+z*z*s41_2*s41_1))

phi12=R12*Q12+abs(z)*J12
phi23=R23*Q23+abs(z)*J23
phi34=R34*Q34+abs(z)*J34
phi41=R41*Q41+abs(z)*J41

f=1
if x<=x1 or x>=x3:
    f=0
    
if y<=y1 or y>=y3:
    f=0

phi=phi12+phi23+phi34+phi41-np.absolute(z)*2*np.pi*f


print(phi)


