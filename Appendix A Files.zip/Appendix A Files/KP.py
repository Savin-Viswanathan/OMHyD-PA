# Calculation for velocity potential at point (x,y,z!=0) due to unit source density distribution on quadrilateral panel with vertices given by pan[5], pan[6], pan[7]
# and pan[8] based on analytical formulation in p. 245 of the book by Katz and Plotkin (1975): Low Speed Aerodynamics (second edition); This code is corrected for
# compliance of results with other formulations.

import numpy as np
import math

cplx=0
cply=0
cplz=-25

pan=np.zeros((9),dtype=np.ndarray)
pan[5]=np.array([-2.5,-2.5])
pan[6]=np.array([-2.5,2.5])
pan[7]=np.array([2.5,2.5])
pan[8]=np.array([2.5,-2.5])

            
d12=np.sqrt((pan[6][0]-pan[5][0])*(pan[6][0]-pan[5][0])
            +(pan[6][1]-pan[5][1])*(pan[6][1]-pan[5][1]))
            
d23=np.sqrt((pan[7][0]-pan[6][0])*(pan[7][0]-pan[6][0])
            +(pan[7][1]-pan[6][1])*(pan[7][1]-pan[6][1]))
            
d34=np.sqrt((pan[8][0]-pan[7][0])*(pan[8][0]-pan[7][0])
            +(pan[8][1]-pan[7][1])*(pan[8][1]-pan[7][1]))
            
d41=np.sqrt((pan[5][0]-pan[8][0])*(pan[5][0]-pan[8][0])
            +(pan[5][1]-pan[8][1])*(pan[5][1]-pan[8][1]))
'''            
if(abs(pan[6][0]-pan[5][0])<0.000001):
    x2mx1=0.000001
else:
    x2mx1=pan[6][0]-pan[5][0]
                
if(abs(pan[7][0]-pan[6][0])<0.000001):
    x3mx2=0.000001
else:
    x3mx2=pan[7][0]-pan[6][0]
                 
if(abs(pan[8][0]-pan[7][0])<0.000001):
    x4mx3=0.000001
else:
    x4mx3=pan[8][0]-pan[7][0]
            
if(abs(pan[5][0]-pan[8][0])<0.000001):
    x1mx4=0.000001
else:
    x1mx4=pan[5][0]-pan[8][0]
            
m12=(pan[6][1]-pan[5][1])/x2mx1
m23=(pan[7][1]-pan[6][1])/x3mx2
m34=(pan[8][1]-pan[7][1])/x4mx3
m41=(pan[5][1]-pan[8][1])/x1mx4
'''
#calculate m12
if abs(pan[6][0]-pan[5][0])<0.000001:
    if (pan[6][1]-pan[5][1])>0:
        m12=np.inf
    elif (pan[6][1]-pan[5][1])<0:
        m12=-np.inf
elif abs(pan[6][1]-pan[5][1])<0.000001:
    if (pan[6][0]-pan[5][0])>0:
        m12=0
    elif (pan[6][0]-pan[5][0])<0:
        m12=0
else:
    m12=(pan[6][1]-pan[5][1])/(pan[6][0]-pan[5][0])
            
#calculate m23
if abs(pan[7][0]-pan[6][0])<0.000001:
    if (pan[7][1]-pan[6][1])>0:
        m23=np.inf
    elif (pan[7][1]-pan[6][1])<0:
        m23=-np.inf
elif abs(pan[7][1]-pan[6][1])<0.000001:
    if (pan[7][0]-pan[6][0])>0:
        m23=0
    elif (pan[7][0]-pan[6][0])<0:
        m23=0
else:
    m23=(pan[7][1]-pan[j][6][1])/(pan[7][0]-pan[6][0])
            
#calculate m34
if abs(pan[8][0]-pan[7][0])<0.000001:
    if (pan[8][1]-pan[7][1])>0:
        m34=np.inf
    elif (pan[8][1]-pan[7][1])<0:
        m34=-np.inf
elif abs(pan[8][1]-pan[7][1])<0.000001:
    if (pan[8][0]-pan[7][0])>0:
        m34=0
    elif (pan[8][0]-pan[7][0])<0:
        m34=0
else:
    m34=(pan[8][1]-pan[7][1])/(pan[8][0]-pan[7][0])
            
            
#calculate m41
if abs(pan[5][0]-pan[8][0])<0.000001:
    if (pan[5][1]-pan[8][1])>0:
        m41=np.inf
    elif (pan[5][1]-pan[8][1])<0:
        m41=-np.inf
elif abs(pan[5][1]-pan[8][1])<0.000001:
    if (pan[5][0]-pan[8][0])>0:
        m41=0
    elif (pan[5][0]-pan[8][0])<0:
        m41=0
else:
    m41=(pan[5][1]-pan[8][1])/(pan[5][0]-pan[8][0])


r1=np.sqrt((cplx-pan[5][0])*(cplx-pan[5][0])+(cply-pan[5][1])*(cply-pan[5][1])+cplz*cplz)
r2=np.sqrt((cplx-pan[6][0])*(cplx-pan[6][0])+(cply-pan[6][1])*(cply-pan[6][1])+cplz*cplz)
r3=np.sqrt((cplx-pan[7][0])*(cplx-pan[7][0])+(cply-pan[7][1])*(cply-pan[7][1])+cplz*cplz)
r4=np.sqrt((cplx-pan[8][0])*(cplx-pan[8][0])+(cply-pan[8][1])*(cply-pan[8][1])+cplz*cplz)
            
            
e1=(cplx-pan[5][0])*(cplx-pan[5][0])+cplz*cplz
e2=(cplx-pan[6][0])*(cplx-pan[6][0])+cplz*cplz
e3=(cplx-pan[7][0])*(cplx-pan[7][0])+cplz*cplz
e4=(cplx-pan[8][0])*(cplx-pan[8][0])+cplz*cplz
            
h1=(cply-pan[5][1])*(cplx-pan[5][0])
h2=(cply-pan[6][1])*(cplx-pan[6][0])
h3=(cply-pan[7][1])*(cplx-pan[7][0])
h4=(cply-pan[8][1])*(cplx-pan[8][0])

rz=(np.arctan((m12*e1-h1)/(cplz*r1))-np.arctan((m12*e2-h2)/(cplz*r2))
    +np.arctan((m23*e2-h2)/(cplz*r2))-np.arctan((m23*e3-h3)/(cplz*r3))
    +np.arctan((m34*e3-h3)/(cplz*r3))-np.arctan((m34*e4-h4)/(cplz*r4))
    +np.arctan((m41*e4-h4)/(cplz*r4))-np.arctan((m41*e1-h1)/(cplz*r1)))

r_inv=((((cplx-pan[5][0])*(pan[6][1]-pan[5][1])-(cply-pan[5][1])*(pan[6][0]-pan[5][0]))/d12
        *math.log((r1+r2+d12)/(r1+r2-d12))
        +((cplx-pan[6][0])*(pan[7][1]-pan[6][1])-(cply-pan[6][1])*(pan[7][0]-pan[6][0]))/d23
        *math.log((r2+r3+d23)/(r2+r3-d23))
        +((cplx-pan[7][0])*(pan[8][1]-pan[7][1])-(cply-pan[7][1])*(pan[8][0]-pan[7][0]))/d34
        *math.log((r3+r4+d34)/(r3+r4-d34))
        +((cplx-pan[8][0])*(pan[5][1]-pan[8][1])-(cply-pan[8][1])*(pan[5][0]-pan[8][0]))/d41
        *math.log((r4+r1+d41)/(r4+r1-d41))- abs(cplz)*rz))

print(r_inv)

