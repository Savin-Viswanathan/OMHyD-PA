# Calculation for velocity potential at point (x,y,z!=0) due to unit source density distribution on quadrilateral panel with vertices (x1,y1), (x2,y2),
# (x3,y3), and (x4,y4) based on integral formulation in the paper by Faltinsen and Michelsen (1975): Motions of Large Structures in Waves at Zero Froude
# Numbers.
import numpy as np
import math
from scipy.integrate import quad

x=0
y=0
z=-25

x1=-2.5
y1=-2.5

x2=-2.5
y2=2.5

x3=2.5
y3=2.5

x4=2.5
y4=-2.5

x12i=x2-x1
x23i=x3-x2
x34i=x4-x3
x41i=x1-x4

y12=y2-y1
y23=y3-y2
y34=y4-y3
y41=y1-y4

if x12i==0:
    x12=0.000001
else:
    x12=x12i
if x23i==0:
    x23=0.000001
else:
    x23=x23i
if x34i==0:
    x34=0.000001
else:
    x34=x34i
if x41i==0:
    x41=0.000001
else:
    x41=x41i
    
sr_inv1,err1=quad(lambda xi: math.log((y-(y1+y12/x12*(xi-x1)))+np.sqrt((y-(y1+y12/x12*(xi-x1)))*(y-(y1+y12/x12*(xi-x1)))+(x-xi)*(x-xi)+z*z)),x1,x2)
sr_inv2,err2=quad(lambda xi: math.log((y-(y2+y23/x23*(xi-x2)))+np.sqrt((y-(y2+y23/x23*(xi-x2)))*(y-(y2+y23/x23*(xi-x2)))+(x-xi)*(x-xi)+z*z)),x2,x3)
sr_inv3,err3=quad(lambda xi: math.log((y-(y3+y34/x34*(xi-x3)))+np.sqrt((y-(y3+y34/x34*(xi-x3)))*(y-(y3+y34/x34*(xi-x3)))+(x-xi)*(x-xi)+z*z)),x3,x4)
sr_inv4,err4=quad(lambda xi: math.log((y-(y4+y41/x41*(xi-x4)))+np.sqrt((y-(y4+y41/x41*(xi-x4)))*(y-(y4+y41/x41*(xi-x4)))+(x-xi)*(x-xi)+z*z)),x4,x1)

sr_inv=-(sr_inv1+sr_inv2+sr_inv3+sr_inv4)

print(sr_inv)
print(err1,err2,err3,err4)

             



