#file diff_3d_obj_func
import numpy as np
import math
import gradif
import scipy.special as scisp
from scipy import linalg
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d
import matplotlib.cm as cm

#Hydrodynamcis master
#***************************************************************************************************
def Hyd_mstr(ps,coldist,b_c,fs_c,z_cg,rho,g,waves,omega,wav_dir,geom,fp_data,plane,xlm,ylm,zlm,b_disp='yes',
             i_disp='yes',fs_disp='yes',n_rad_freq=35,sf_rad=100,vf=np.array([1,0,0]),
             L=10,B=10,H=10,draft=10,imm_d=7,ndL=1,ndL1=1,norm='yes',diag='yes',source='yes',
             surge='yes',sway='yes',heave='yes',roll='yes',pitch='yes',yaw='yes',source_str='no'):
    
    #Step1: Unit Conversions>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    w_d=wav_dir*np.pi/180 #convert wave direction to radians
    
    #Step2: Plotting the body/image and free surface>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    if geom in ['cuboidal']: #if body is cuboidal
        
        #plot definitions
        font = {'family': 'serif',
        'color':  'darkred',
        'weight': 'normal',
        'size': 24,
        }
        fig=plt.figure(figsize=(15,15))
        ax =fig.add_subplot(111, projection='3d')
        ax.set_xlim(xlm)
        ax.set_ylim(ylm)
        ax.set_zlim(zlm)
        ax.set_xlabel('x [m]',fontdict=font,labelpad=20)
        ax.set_ylabel('y [m]',fontdict=font,labelpad=20)
        ax.set_zlabel('z [m]',fontdict=font,labelpad=20)
        ax.tick_params(labelsize=16)
        
        #select values of parameters to avoid conflicting scenarios
        if b_c in ['floating']: #if boday is floating, set immersion depth to '0'and free surface to 'yes'
            imm_d=0
            fs_c='yes'
        elif b_c in ['submerged']:
            imm_d=imm_d #if body is submerged, then retain specified immersion depth
        else:
            print('Body condition error') #if there is error in specification of body conditions, display error message and exit
            exit()
            
        #determine body plotting parameters    
        x,y,z,nsp,a,b,c,d,e,f,c_img,d_img,e_img,f_img,x1,x2,y1,y2,z1,z2,a0,b0,z0=(
            cube_param(L,B,H,draft,imm_d,ps,b_c,fs_c,xlm,ylm)) #call function 'cube_param' which returns the plotting parameters for a cuboidal body
        
        #plot body/image
        plt_cube(ax,L,b_c,fs_c,a,b,c,d,e,f,c_img,d_img,e_img,f_img,x1,x2,y1,y2,z1,z2,a0,b0,z0,xlm,ylm,zlm,i_disp) #call function 'plt_cube' to plot the body and/or image
        
        #display progress message
        print('Body plot parameters calculated')
        
        
        #determine panel vertices
        vert,verti,z_bp,z_tp=panel_vertices_cuboidal(b_c,fs_c,L,B,H,imm_d,draft,x,y,z,nsp)
        
        #determine and store panel parameters
        pan=np.zeros((nsp),dtype=np.ndarray)#vector with each element containing body panel parameters
        pani=np.zeros((nsp),dtype=np.ndarray)# vector with each element contianing source panel parameters
        for i in range(len(pan)):
            D1,D2,n,l,p,c,v1lx,v1ly,v2lx,v2ly,v3lx,v3ly,v4lx,v4ly,cp=panel_par(vert[i][0],vert[i][1],vert[i][2],
                                                                               vert[i][3],coldist)# call function 'panel_par' to calculate body panel parameters
            pan[i]=([vert[i],c,n,l,p,np.array([v1lx,v1ly]),
                        np.array([v2lx,v2ly]),np.array([v3lx,v3ly]),
                        np.array([v4lx,v4ly]),cp,D1,D2])#store calculated panel parameters as the n-dimensional element of a vector
        
            if diag in ['yes']: #plot diagonals of body panels by calling function 'plt_diag'
                plt_diag(ax,pan[i][0][0],pan[i][0][1],pan[i][10],pan[i][11])
            if norm in ['yes']: #plot normals of body panels by calling function 'plt_norm'
                plt_norm(ax,pan[i][1],pan[i][2])
            if source in ['yes']:#plt collocation points of body panels by calling function 'plt_src'
                plt_src(ax,pan[i][9])
            
            if fs_c in ['yes']: #if there is a free surface, then call function 'panel_par' to calculate image panel parameters
                D1,D2,n,l,p,c,v1lx,v1ly,v2lx,v2ly,v3lx,v3ly,v4lx,v4ly,cp=panel_par(verti[i][0],verti[i][1],verti[i][2],
                                                                                   verti[i][3],coldist)
                pani[i]=([verti[i],c,n,l,p,np.array([v1lx,v1ly]),
                            np.array([v2lx,v2ly]),np.array([v3lx,v3ly]),
                            np.array([v4lx,v4ly]),cp,D1,D2])#store calculated panel parameters as the n-dimensional element of a vector
                if diag in ['yes']:#plot diagonals of image panels by calling function 'plt_diag'
                    plt_diag(ax,pani[i][0][0],pani[i][0][1],pani[i][10],pani[i][11])
                if norm in ['yes']:#plot normals of image panels by calling function 'plt_norm'
                    plt_norm(ax,pani[i][1],pani[i][2])
                if source in ['yes']:#plt collocation points of image panels by calling function 'plt_src'
                    plt_src(ax,pani[i][9])
    else:#if there is any error in the body or free surface definitions, then display error message and exit
        print('Body not defined! Process terminated.')
        exit()
    print('Panel parameters calculated') #display progress message if this stage is reached without problems
    
    #Step3: Calculate hydrostatics>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    pan_area=hydrostatics(pan,b_c,rho,g,ndL1,z_cg)#calculate and display hydrostatics by calling function 'hydrostatics'. Get the panel area for further calculation
    print('Hydrostatics calculated')
    
    #Step4: Calculate the integral of the non-wavy part of the Green function and its derivatives 
    #using analytical methods from Hess & Smith/Katz & plotkin>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    dnr,dnri,r_inv,ri_inv,iv,ivi=non_wav_green_func(pan,pani,fs_c) #call function 'non_wav_green_func' to calculate the non-wavy part
   
   
    if waves in ['on']: #if the waves are 'on', then diffraction-radiation problem is considered, else jump to Step 16.
        
        #Step5: Determine the generalized normals>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
        n_gen_grp=np.zeros(len(pan),dtype=np.ndarray)#initialize vector of group of generalized normals
        n_gen=np.zeros(len(pan),dtype=np.ndarray)#initialize vector of individual generalized normals
        
        for i in range(len(pan)):#determine generalized normals  
            n_gen_grp[i]=[pan[i][2],np.cross(pan[i][1],pan[i][2])]#gen norm groups
            n_gen[i]=[n_gen_grp[i][0][0],n_gen_grp[i][0][1],n_gen_grp[i][0][2],
                             n_gen_grp[i][1][0],n_gen_grp[i][1][1],n_gen_grp[i][1][2]]#gen norm vector
                                          
        #Declare vectors/matrices to hold different variables                                                   
        omega_nd=np.zeros(len(omega))#initialize vector of non. dim frequencies
        qty_nd=np.zeros(len(omega))
        
        a=np.zeros((len(omega),6,6),dtype=np.ndarray)# intialize dimensional added mass matrix
        b=np.zeros((len(omega),6,6),dtype=np.ndarray)# intialize dimensional damping matrix
        
        a_nd=np.zeros((len(omega),6,6),dtype=np.ndarray)# intialize non-dimensional added mass matrix
        b_nd=np.zeros((len(omega),6,6),dtype=np.ndarray)# intialize non-dimensional damping matrix
        
        dof=np.empty(0,dtype=int)# initialize (empty) holder for degree of freedom

        if surge in ['yes']:
            dof=np.append(dof,1)# if surge is to be considered append '1' to the dof holder vector

        if sway in ['yes']:
            dof=np.append(dof,2)# if sway is to be considered append '2' to the dof holder vector
            
        if heave in ['yes']:
            dof=np.append(dof,3)# if heave is to be considered append '3' to the dof holder vector

        if roll in ['yes']:
            dof=np.append(dof,4)# if roll is to be considered append '4' to the dof holder vector

        if pitch in ['yes']:
            dof=np.append(dof,5)# if pitch is to be considered append '5' to the dof holder vector

        if yaw in ['yes']:
            dof=np.append(dof,6)# if yaw is to be considered append '6' to the dof holder vector
            
        exf=np.zeros((len(omega),6),dtype=complex)#initialize 6X6 excitation force matrix to hold complex values
        
        for i in range(len(omega)):#for each wave frequency, carry out steps below
            alpha=np.zeros((len(pan),len(pan)),dtype=complex)#initialize 'alpha' matrix of size npan X npan  to  store the
                                                            #normal component of induced velocities at each panel null point
                                                            #for unit source density distribution over the panels
            beta=np.zeros((len(pan),len(pan)),dtype=complex)#initialize 'beta'matrix of size npan X npan to store the velocity potential
                                                            #at panel null points for unit source density distribution  over panels
            
            #Step6: Determine the wavy part of the green function>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            sG0,sdG0_n=wav_green_func(pan,omega[i],ndL,g,coldist,pan_area) #determine the wavy part of the Green function and its normal derivative at the collocation
                                                                                #point of panel 'i' due to unit source density distribution over panel 'j'
            #Step7: Determine the Alpha and Beta matrices for panel centroids>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            alpha=dnr+dnri+sdG0_n #determine the matrix 'alpha' containing the normal derivatives of induced velocities at panel null points
            alphainv=linalg.inv(alpha)#determine the inverse of 'alpha'
            
            beta=r_inv+ri_inv+sG0 #determine the matrix 'beta' contianing the induced velocity potentials at panel null points
                
            #initialize vectors for storing normal velocities of panel null points for motion with unit velocities/angular velocities in each DoF
            vn1=np.zeros(len(pan),dtype=complex)#null point normal velocities for oscillation with unit velocity in surge direction
            vn2=np.zeros(len(pan),dtype=complex)#null point normal velocities for oscillation with unit velocity in sway direction
            vn3=np.zeros(len(pan),dtype=complex)#null point normal velocities for oscillation with unit velocity in heave direction
            vn4=np.zeros(len(pan),dtype=complex)#null point normal velocities for oscillation with unit angular velocity in roll direction
            vn5=np.zeros(len(pan),dtype=complex)#null point normal velocities for oscillation with unit angular velocity in pitch direction
            vn6=np.zeros(len(pan),dtype=complex)#null point normal velocities for oscillation with unit angular velocity in yaw direction
            
            #Step8: Determine normal velocities at the centroid of each panel for specified DoFs>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            for j in range(len(pan)):# determine normal velocities above as required
                if surge in ['yes']:
                    vn1[j]=complex(0,1)*omega[i]*n_gen[j][0]
                   
                if sway in ['yes']:
                    vn2[j]=complex(0,1)*omega[i]*n_gen[j][1]
                    
                if heave in ['yes']:
                    vn3[j]=complex(0,1)*omega[i]*n_gen[j][2]
                   
                if roll in ['yes']:
                    vn4[j]=complex(0,1)*omega[i]*n_gen[j][3]
                    
                if pitch in ['yes']:
                    vn5[j]=complex(0,1)*omega[i]*n_gen[j][4]
                    
                if yaw in ['yes']:
                    vn6[j]=complex(0,1)*omega[i]*n_gen[j][5]
                    
            #Step9: Determine source densities corresponding to velocities above, which are equal to the fluid velocity at the panel centroid
                #due to the radiated wave.>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            #initialize vector to hold source densities corresponding to normal velocities above
            sigma1=np.zeros(len(pan),dtype=complex)
            sigma2=np.zeros(len(pan),dtype=complex)
            sigma3=np.zeros(len(pan),dtype=complex)
            sigma4=np.zeros(len(pan),dtype=complex)
            sigma5=np.zeros(len(pan),dtype=complex)
            sigma6=np.zeros(len(pan),dtype=complex)
            
            #determine corresponding source densities as required
            if surge in ['yes']:
                sigma1=np.matmul(alphainv,vn1)
                   
            if sway in ['yes']:
                sigma2=np.matmul(alphainv,vn2)
                    
            if heave in ['yes']:
                sigma3=np.matmul(alphainv,vn3)
                   
            if roll in ['yes']:
                sigma4=np.matmul(alphainv,vn4)
                    
            if pitch in ['yes']:
                sigma5=np.matmul(alphainv,vn5)
                    
            if yaw in ['yes']:
                sigma6=np.matmul(alphainv,vn6)
                
            # store value of sigma for plotting effect of wavy part of green function
            if i==n_rad_freq and fp_data in ['yes'] :
                print(omega[i])
                if surge in ['yes'] and sway in ['no'] and heave in ['no'] and roll in ['no'] and pitch in ['no'] and yaw in ['no']:
                    sigma=sigma1.real
                    print('Wavy part of Green function will be plotted for 1st DoF')
                elif surge in ['no'] and sway in ['yes'] and heave in ['no'] and roll in ['no'] and pitch in ['no'] and yaw in ['no']:
                    sigma=sigma2.real
                    print('Wavy part of Green function will be plotted for 2nd DoF')
                elif surge in ['no'] and sway in ['no'] and heave in ['yes'] and roll in ['no'] and pitch in ['no'] and yaw in ['no']:
                    sigma=sigma3.real
                    print('Wavy part of Green function will be plotted for 3rd DoF')
                elif surge in ['no'] and sway in ['no'] and heave in ['no'] and roll in ['yes'] and pitch in ['no'] and yaw in ['no']:
                    sigma=sigma4.real
                    print('Wavy part of Green function will be plotted for 4th DoF')
                elif surge in ['no'] and sway in ['no'] and heave in ['no'] and roll in ['no'] and pitch in ['yes'] and yaw in ['no']:
                    sigma=sigma5.real
                    print('Wavy part of Green function will be plotted for 5th DoF')
                elif surge in ['no'] and sway in ['no'] and heave in ['no'] and roll in ['no'] and pitch in ['no'] and yaw in ['yes']:
                    sigma=sigma6.real
                    print('Wavy part of Green function will be plotted for 6th DoF')
                else:
                    fp_data='no'
                    print('More than one DoF specified for plotting effects if wavy Green function. This is an error, hence effects of'
                    'wavy green function will not be plotted')
                    
            #Intialize vector to hold radiation potentials corresponding to source densities determined above
            phi1=np.zeros(len(pan),dtype=complex)
            phi2=np.zeros(len(pan),dtype=complex)
            phi3=np.zeros(len(pan),dtype=complex)
            phi4=np.zeros(len(pan),dtype=complex)
            phi5=np.zeros(len(pan),dtype=complex)
            phi6=np.zeros(len(pan),dtype=complex)
            
            #Step10: Determine radiaiton potentials as required at panel centroids>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            for j in range(len(pan)): 
                for k in range(len(pan)):
                    if surge in ['yes']:
                        phi1[j]=phi1[j]+beta[j][k]*sigma1[k]
                        
                    if sway in ['yes']:
                        phi2[j]=phi2[j]+beta[j][k]*sigma2[k]
                    
                    if heave in ['yes']:
                        phi3[j]=phi3[j]+beta[j][k]*sigma3[k]
                    
                    if roll in ['yes']:
                        phi4[j]=phi4[j]+beta[j][k]*sigma4[k]
                    
                    if pitch in ['yes']:
                        phi5[j]=phi5[j]+beta[j][k]*sigma5[k]
                    
                    if yaw in ['yes']:
                        phi6[j]=phi6[j]+beta[j][k]*sigma6[k]
            
            phi=np.empty(len(pan),dtype=np.ndarray) #initialize vector of vectors to store the radiation potentials
            for j in range(len(pan)):#store radiation potentials as a vector of vectors associated with each panel
                phi[j]=[phi1[j],phi2[j],phi3[j],phi4[j],phi5[j],phi6[j]]
                        
            #Step11: calculate added mass, damping>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            for j in range(len(dof)):
                for k in range(j,len(dof)):
                    jl=dof[j]-1 #manipulation for storage 
                    kl=dof[k]-1 #manipulation for storage
                    for l in range(len(pan)):
                        a[i][jl][kl]=a[i][jl][kl]-rho/omega[i]*n_gen[l][jl]*phi[l][kl].imag*pan_area[l] #calculate added mass due to radiation potential associated with each panel
                        a[i][kl][jl]=a[i][jl][kl]# sum up the added masses
                        
                        b[i][jl][kl]=b[i][jl][kl]-rho*n_gen[l][jl]*phi[l][kl].real*pan_area[l]#calculate damping due to radiation potential associated with each panel
                        b[i][kl][jl]=b[i][jl][kl]# sum up the damping
            
            #Step12: Determine the scattering potential (also called diffraction potential) and its derivatives>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            vn_d=np.zeros(len(pan),dtype=complex) #initialize vector to hold normal velocities induced by the diffraction potential at collocation points
            sigma_d=np.zeros(len(pan),dtype=complex)#initialize vector to hold source density distributions to impose impenetrability at collocation points
            phi_d=np.zeros(len(pan),dtype=complex)# initialize vector to hold diffraction potential value at each collocation point
            phi_I_d=np.zeros(len(pan),dtype=complex)# initialize vector to hold incident potential value at each collocation point
            for l in range(len(pan)):
                k_w=omega[i]*omega[i]/g #determine wave number associated with each frequency 'i'
                
                phi_I=complex(0,1)*g/omega[i]*np.exp(-complex(0,1)*k_w*(pan[l][1][0]*np.cos(w_d)-pan[l][1][1]*np.sin(w_d))
                                                     )*np.exp(k_w*pan[l][1][2])#determine incident potential at panel centroid
                
                phi_I_dx=omega[i]*np.cos(w_d)*np.exp(-complex(0,1)*k_w*(pan[l][1][0]*np.cos(w_d)-pan[l][1][1]*np.sin(w_d))
                                                        )*np.exp(k_w*pan[l][1][2])#determine x directional derivative of incident potential at panel centroid
                
                phi_I_dy=omega[i]*np.sin(w_d)*np.exp(-complex(0,1)*k_w*(pan[l][1][0]*np.cos(w_d)-pan[l][1][1]*np.sin(w_d))
                                                        )*np.exp(k_w*pan[l][1][2])# determine y directional derivative of incident potential at panel centroid
                
                phi_I_dz=complex(0,1)*omega[i]*np.exp(-complex(0,1)*k_w*(pan[l][1][0]*np.cos(w_d)-pan[l][1][1]*np.sin(w_d))
                                                        )*np.exp(k_w*pan[l][1][2])#determine z directional derivative of incident potential at panel centroid
                        
                phi_I_dn=phi_I_dx*pan[l][2][0]+phi_I_dy*pan[l][2][1]+phi_I_dz*pan[l][2][2] #determine normal derivative of incident potential at panel centroid
                
                vn_d[l]=-phi_I_dn#set normal velocity due to diffraction potential equal to -ve of normal velocity due to incident potential at each panel centroid
                phi_I_d[l]=phi_I #store incident potential calculated at each step as incident potential at associated panel centroid
                
            #Step13: Determine source density distribution corresponding to the diffraction potential>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>     
            sigma_d=np.matmul(alphainv,vn_d) #calculate vector of source density distributions associated with imposing impenetrability at panel centroids
            
            #Step 14: Determine the excitation forces>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
            for j in range(len(pan)):
                for k in range (len(pan)):
                    phi_d[j]=phi_d[j]+beta[j][k]*sigma_d[k] #calculate vector of diffraction potentials associated with each panel centroid
                
                if surge in ['yes']:
                    exf[i][0]=exf[i][0]-complex(0,1)*omega[i]*rho*(n_gen[j][0]*(phi_I_d[j]+phi_d[j]))*pan_area[j]#calculate surge excitation force
                   
                if sway in ['yes']:
                    exf[i][1]=exf[i][1]-complex(0,1)*omega[i]*rho*(n_gen[j][1]*(phi_I_d[j]+phi_d[j]))*pan_area[j]#calculate sway excitation force
                        
                if heave in ['yes']:
                    exf[i][2]=exf[i][2]-complex(0,1)*omega[i]*rho*(n_gen[j][2]*(phi_I_d[j]+phi_d[j]))*pan_area[j]#calculate heave excitation force
                       
                if roll in ['yes']:
                    exf[i][3]=exf[i][3]-complex(0,1)*omega[i]*rho*(n_gen[j][3]*(phi_I_d[j]+phi_d[j]))*pan_area[j]#calculate roll excitation moment
                        
                if pitch in ['yes']:
                    exf[i][4]=exf[i][4]-complex(0,1)*omega[i]*rho*(n_gen[j][4]*(phi_I_d[j]+phi_d[j]))*pan_area[j]#calculate pitch excitation moment
                        
                if yaw in ['yes']:
                    exf[i][5]=exf[i][5]-complex(0,1)*omega[i]*rho*(n_gen[j][5]*(phi_I_d[j]+phi_d[j]))*pan_area[j]#calculate yaw excitation moment
            print('Added mass, damping and wave excitation force calculated for {} of {} frequencies'.format(i+1,len(omega)))
            
        #Step 15: Write the output file>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
        f=open('am.txt','a+') #open file in read and append mode
        f.truncate(0) #truncate file and cursor positon to 0
        f.write('**********RESULTS FILE**********\n\n') #write file heading
        f.write('Environment:***\n')#indicate begin of envirionment parameters 
        f.write(f'Water Density={rho:4} kg m^-3\nAcceleration of Gravity= {g:4} m s^-2\nWater Depth: Infinite\nFree surface: {fs_c}\nWaves: {waves}\n')#f string format
        #above line prints the water density, acc. of gravity, water depth, presence of free surface, presence of waves
        if waves in ['on']:
            f.write(f'Wave Frequencies: Given below\nCurrent: NA\n\n') #if waves are present, indicate that frequencies are given below and that there is no current
            
        else:
            f.write(f'Wave frequencies: NA\nCurrent: {vf} m/s along [x,y,z] directions\n\n')#if waves are absent , indicate N/A message, and list current vector
        
        f.write(f'Body:***\nGeometry: {geom}\nCondition: {b_c}\nLength= {L} m\nBreadth= {B} m\n')# print body parameters
        if b_c in ['submerged']:
            if fs_c in ['no']: #if submerged body in infinite domain, print immersion depth as infinite
                f.write('Immersion depth= Infinite\n\n')
            else: #if submerged body in presence of free surface, print immersion depth
                f.write(f'Immersion depth= {imm_d} m\n\n')
        if b_c in ['floating']: #if floating body, print draft
            f.write(f'Draft= {draft} m\n\n')
            
        for i in range(len(omega)): #for each wave frequency print the following
            f.write('{:03f}\n'.format(omega[i])) #the frequency
            np.savetxt(f,a[i],fmt='%-15.6E')# the added mass matrix for that frequency
            f.write('\n')# a blank line
            np.savetxt(f,b[i],fmt='%-15.6E')#the damping matrix for that frequency
            f.write('\n')#a blank line
            np.savetxt(f,abs(exf[i]),fmt='%-15.6E')# the excitation force vector for that frequency
            f.write('\n')
            
        f.close()# close the file
        print('Hydrodynamics parameters written to file')#display progress message
        
    elif waves in ['off']:#if waves are absent
        #Step 16: Determine Alpha matrix without the derivative of the wavy part of the Green function>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
        alpha=dnr+dnri
        
        #Step 17: Determine souce densities corresponding to the impermeability condition>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
        alphainv=linalg.inv(alpha)#determine inverse of alpha matrix

        vn=np.zeros(len(pan))#initialize vector to hold null point normal velocities
        for i in range(len(pan)):
            vn[i]=-np.dot(vf,pan[i][2])#calculate null point normal velocties
        #Determine source densities    
        sigma=np.zeros(len(pan))#initialize vector to hold source density distributions
        sigma=np.matmul(alphainv,vn)# calculate source density distributions
        
        #Step 18: Determine total velocities at panel centroids>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
        #***************************************************************************************************
        v_n_tot=np.zeros(len(pan),dtype=np.ndarray)#intialize vector of vectors to hold null point velocity components

        for i in range(len(pan)):
            for j in range(len(pan)):
                v_n_totl=(np.array([sigma[j]*(iv[i][j][0]+ivi[i][j][0]),sigma[j]*(iv[i][j][1]+ivi[i][j][1]),
                                    sigma[j]*(iv[i][j][2]+ivi[i][j][2])]))#calculate panel 'i' null point induced velocity components by source distribution on panel 'j'
                v_n_tot[i]=v_n_tot[i]+v_n_totl#accumulate induced velocity components at null point of panel 'i' due to source densities on all panel 'j's
        
        for i in range(len(pan)):
            v_n_tot[i]=v_n_tot[i]+vf#calculate total velocity at null point of panel 'i'
            (ax.quiver(pan[i][1][0],pan[i][1][1],pan[i][1][2],v_n_tot[i][0],v_n_tot[i][1],
                       v_n_tot[i][2],color='red',pivot='middle'))#quiver plot of velocity at null point of panel 'i'
                    
    #Step 19: Plot Source Strength>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    if source_str in ['yes']: #run following code only if source strength plot is required by the user
        x_src_str=np.zeros(len(pan))
        y_src_str=np.zeros(len(pan))
        z_src_str=np.zeros(len(pan))
        for i in range(len(pan)):
            x_src_str[i]=pan[i][1][0]
            y_src_str[i]=pan[i][1][1]
            z_src_str[i]=pan[i][1][2]
            
        plt_src_str(fig,ax,x_src_str,y_src_str,z_src_str,sigma)
    #Step 19: Determine field point velocities>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 
    if fp_data in ['yes']: #run following code only if field point data is required by the user       
        vfs=ps/2#field velocity is calculated at points separated by a square panel side length
        if plane in ['xy'] or plane in ['xz']:
            x_fp=np.arange(-L,L+vfs,vfs)#uncomment if field points are to lie on  xz or xy planes
        elif plane in ['yz']:
            x_fp=np.array([0])
            
        if plane in ['xy'] or plane in ['yz']:
            y_fp=np.arange(-L,L+vfs,vfs)#uncomment if field points are to lie on yz or xy planes
        elif plane in ['xz']:
            y_fp=np.array([0])#uncomment if field points lie on the xz plane
        else:
            print('Error in field point plane definition. Program terminated.')
            exit()
        if fs_c in ['yes']:
            if plane in ['xz'] or plane in ['yz']:
                z_fp=np.arange(-L,0+vfs,vfs)#if there is a free surface, then assign z range of field points
            elif plane in ['xy']:
                z_fp=np.array([0])#uncomment if field points line on the xy plane
            else:
                print('Error in field point plane definition. Program terminated.')
                exit()
        elif fs_c in ['no']:
            if plane in ['xz'] or plane in ['yz']:
                z_fp=np.arange(-L,L+vfs,vfs)#
            elif plane in ['xy']:
                z_fp=np.array([0])
            else:
                print('Error in field point plane definition. Program terminated.')
                exit()
        
        fp=np.zeros((len(x_fp)*len(y_fp)*len(z_fp)),dtype=np.ndarray)#initialize vector of vectors to hold field point coordinates
        count=0#initialize count 
        for i in range(len(z_fp)):
            for j in range(len(y_fp)):
                for k in range(len(x_fp)):
                    fp[count]=[x_fp[k],y_fp[j],z_fp[i]]#store field point coordinates
                    count=count+1#increment count
            
        iv_fp,ivi_fp=field_point_vel(fp,pan,pani,sigma,L,B,z_bp,z_tp,ps,fs_c)#calculate induced velocities due to source and image panels by calling function 'field_point_vel'

        v_fp=np.zeros(len(iv_fp),dtype=np.ndarray)#initialize vector of vectors to store the field point velocity components
        if waves in ['on']:
            sf=sf_rad
            con_i=0
        else:
            sf=1
            con_i=1
        for i in range(len(fp)):
            sumx=0#initialize sums of x, y,z velocity components to zero
            sumy=0
            sumz=0
            for j in range(len(pan)):
                sumx=sumx+sf*iv_fp[i][j][0]+con_i*ivi_fp[i][j][0]#sum up x component of induced velocity at field point 'i' due to source and image panels
                sumy=sumy+sf*iv_fp[i][j][1]+con_i*ivi_fp[i][j][1]#sum up y component of induced velocity at field point 'i' due to source and image panels
                sumz=sumz+sf*iv_fp[i][j][2]+con_i*ivi_fp[i][j][2]#sum up z component of induced velocity at field point 'i' due to source and image panels
            v_fp[i]=(sumx,sumy,sumz)#store induced velocity component as vector of vectors associated to each field point 'i'
            if (fp[i][0]<=-(L/2+ps) or fp[i][0]>=L/2+ps or  fp[i][1]>=B/2+ps or
                    fp[i][1]<=-(B/2+ps) or fp[i][2]>=z_tp+ps or fp[i][2]<=z_bp-ps):#consider only field points lying one characteristic panel length from body surface
                ax.quiver(fp[i][0],fp[i][1],fp[i][2],sumx+vf[0],sumy+vf[1],sumz+vf[2],pivot='middle')#quiver plot of field point velocities
    plt.show()
    return()
    

#Functions used by the Hyrdodynamics master function
#***************************************************************************************************
#***************************************************************************************************
def cube_param (L,B,H,draft,imm_d,ps,b_c,fs_c,xlm,ylm):
    "function to determine the plotting parameters of a cuboidal body and free surface"     
    x=np.arange(-L/2,L/2+ps,ps)#set x limit
    y=np.arange(-B/2,B/2+ps,ps)#set y limit
    a,b=np.meshgrid(x,y) #meshgrid points for xy grid
    
    if b_c in ['floating']: #if floating body, lower surface is at '-draft'
        z=np.arange(-draft,ps,ps)#set z limit from -draft to free surface at z=0
        nsp=(len(y)-1)*(len(x)-1)+2*((len(z)-1)*(len(y)-1))+2*((len(z)-1)*(len(x)-1))#calculate number of panels
        z_img=np.arange(0,draft+ps,ps)#set image z limit from free surface 'z=0' to 'z=draft'
        z1=-(draft)*np.ones((a.shape[0],a.shape[1]))#determine z position of bottom surface
        z2=0#since object is floating, the the object is truncated at the free durface
        
    if b_c in['submerged']: #if body is submerged, lower surface is at '-imm_d-H/2'
        if fs_c in ['yes']: #if free surface exisits and hence image panels are also to be modelled
            z=np.arange(-imm_d-H/2,-imm_d+H/2+ps,ps) #set z limit for grid
            nsp=(2*(len(y)-1)*(len(x)-1))+2*((len(z)-1)*(len(y)-1))+2*((len(z)-1)*(len(x)-1)) #calculate number of source panels
            z_img=np.arange(imm_d-H/2,imm_d+H/2+ps,ps) #z limit of the image
            z1=-(imm_d+H/2)*np.ones((a.shape[0],a.shape[1]))#z coordinates of the body bottom surface
            z2=(-imm_d+H/2)*np.ones((a.shape[0],a.shape[1]))#z coordinates of body top surface
        if fs_c in ['no']:#if there is no free surface, image panels cannot be modelled
            z=np.arange(-H/2,H/2+ps,ps)#since fluid domain is infinite, z=0 can be chosen as body centroid and z limits set
            nsp=(2*(len(y)-1)*(len(x)-1))+2*((len(z)-1)*(len(y)-1))+2*((len(z)-1)*(len(x)-1))#calculate number of source panels
            z1=-H/2*np.ones((a.shape[0],a.shape[1]))#set z coordinates of the top surface
            z2=H/2*np.ones((a.shape[0],a.shape[1])) #set z coordinate of the bottom surface
               
    if fs_c in ['yes']: #if there is a free surface, then a mesh needs to be generated to represent it
        #free surface mesh generation 
        x0=np.arange(xlm[0],xlm[1]+ps,ps)#set x limit
        y0=np.arange(ylm[0],ylm[1]+ps,ps)#set y limit
        
        a0,b0=np.meshgrid(x0,y0)#xy gridpoints for free surface
        z0=np.zeros((a0.shape[0],a0.shape[1]))#specify z coordinates of the free surface
        
        c_img,d_img=np.meshgrid(y,z_img)#yz grid points  for plotting image wiremesh
        e_img,f_img=np.meshgrid(z_img,x)#zx grid points  for plotting image wiremesh
        
    
    if fs_c in ['no']: #if there is no free surface, then set associated parameters to '0'
        x0,y0,a0,b0,z0=0,0,0,0,0
        c_img,d_img,e_img,f_img=0,0,0,0
        
    c,d=np.meshgrid(y,z)#parameters for plotting body surface
    e,f=np.meshgrid(z,x)#parameters for plotting body surface
    x1=-L/2*np.ones((c.shape[0],c.shape[1]))#x value of aft surface
    x2=L/2*np.ones((c.shape[0],c.shape[1]))#x value of fwd surface
    y1=-B/2*np.ones((e.shape[0],e.shape[1]))#y value of stbd surface
    y2=B/2*np.ones((e.shape[0],e.shape[1]))#y value of port surface
    return(x,y,z,nsp,a,b,c,d,e,f,c_img,d_img,e_img,f_img,x1,x2,y1,y2,z1,z2,a0,b0,z0)
#***************************************************************************************************
def plt_cube (ax,L,b_c,fs_c,a,b,c,d,e,f,c_img,d_img,e_img,f_img,x1,x2,y1,y2,z1,z2,a0,b0,z0,xlm,ylm,zlm,i_disp):       
    "function to plot the body and/or image surface panels for a cuboidal object"  
    ax.plot_surface(a,b,z1,color='pink',alpha=0.5,edgecolors='pink',linewidth=0.5)#plot bottom surface
    ax.plot_surface(x1,c,d,color='pink',alpha=0.5,edgecolors='pink',linewidth=0.5)#plot aft surface
    ax.plot_surface(x2,c,d,color='pink',alpha=0.5,edgecolors='pink',linewidth=0.5)#plot fwd surface
    ax.plot_surface(f,y1,e,color='pink',alpha=0.5,edgecolors='pink',linewidth=0.5)#plot stbd surface
    ax.plot_surface(f,y2,e,color='pink',alpha=0.5,edgecolors='pink',linewidth=0.5)#plot port surface
            
    if b_c in ['submerged']: #if submerged body, then we need to plot body top surface 
        ax.plot_surface(a,b,z2,color='pink',alpha=0.5,edgecolors='pink',linewidth=0.5)#plot top surface
        if fs_c in ['yes'] and i_disp in ['yes']: #if submerged body and there is a free surface, then ween need to plot the image of the  body top surface
            ax.plot_wireframe(a,b,-z2,color='grey',linestyle='dashed')#plot image of top surface
                    
    if fs_c in ['yes']:#if body is not submerged, then
        ax.plot_wireframe(a0,b0,z0,color='brown',linewidth=0.5)#plot mean free surface
        if i_disp in ['yes']:
            ax.plot_wireframe(a,b,-z1,color='grey',linestyle='dashed')#plot image of bottom surface
            ax.plot_wireframe(x1,c_img,d_img,color='grey',linestyle='dashed')#plot image of aft surface
            ax.plot_wireframe(x2,c_img,d_img,color='grey',linestyle='dashed')#plot image of fwd surface
            ax.plot_wireframe(f_img,y1,e_img,color='grey',linestyle='dashed')#plot image of stbd surface
            ax.plot_wireframe(f_img,y2,e_img,color='grey',linestyle='dashed')#plot image of port surface
 
#***************************************************************************************************        
def plt_diag (ax,v1,v2,D1,D2):
    "function to plot diagonals of a panel given its 4 vertices"  
    ax.quiver(v1[0],v1[1],v1[2],D1[0],D1[1],D1[2],linestyle='dashed')
    ax.quiver(v2[0],v2[1],v2[2],D2[0],D2[1],D2[2],linestyle='dashed')
    
#***************************************************************************************************
def plt_norm (ax,c,n):
    "function to plot normals of a panel given its centroid and normal"
    ax.quiver(c[0],c[1],c[2],n[0],n[1],n[2],length=1, color='magenta',linestyle='dashed')
    
#***************************************************************************************************
def plt_src(ax,cp):
    "function to plot collocation source points of a panel given its collocation point coordinates"
    ax.scatter(cp[0],cp[1],cp[2],c='r')

def plt_src_str(fig,ax,x,y,z,s):
    "function to plot collocation source points of a panel given its collocation point coordinates"
    p=ax.scatter(x,y,z,c=s,s=50,cmap='coolwarm',alpha=1)
    #fig.colorbar(p, shrink=0.5)
    cb = fig.colorbar(p, shrink=0.5,orientation='vertical')
    cb.set_label(label='Source strength', size=20)
    cb.ax.tick_params(labelsize=20)
    
                               
#***************************************************************************************************
def panel_vertices_cuboidal(b_c,fs_c,L,B,H,imm_d,draft,x,y,z,nsp):
    "function to determine vertices of panels to represent a cuboidal object with given parameters"
    count=0 #counter for body panel
    counti=0 #counter for image panel
    vert=np.zeros((nsp),dtype=np.ndarray) #vector of length 'no of body panels' to hold vertex information associated with the body panel
    verti=np.zeros((nsp),dtype=np.ndarray) #vector of length 'no of body panels' to hold vertex information associated with the image panel
    #bottom panels**********
    if b_c in ['submerged'] and fs_c in ['yes']: #if submerged body in presence of frees surface, then set z of top and bottom panels
        z_bp=-(imm_d+H/2) #set z of body bottom panels
        z_tp=-imm_d+H/2#set z of body top panels
    elif b_c in ['submerged'] and fs_c in ['no']:#if submerged body in absence of frees surface, then set z of top and bottom panels
        z_bp=-H/2#set z of body bottom panels
        z_tp=H/2#set z of body top panels
    elif b_c in ['floating']:#if floating body, then set z of body bottom panels
        z_bp=-draft#set z of botdy bottom panels
        z_tp=0#z of top surface set to dummy zero, top panels will not be plotted
            
    #bottom panels**********   
    for i in range(len(y)-1):
        for j in range(len(x)-1):
            #Source panels(bottom)**********
            #determine vertices of panel**********
            v1=np.array([x[j],y[i],z_bp])
            v2=np.array([x[j+1],y[i],z_bp])
            v3=np.array([x[j+1],y[i+1],z_bp])
            v4=np.array([x[j],y[i+1],z_bp])
                
            #array of panel vertices**********
            vert[count]=[v1,v2,v3,v4]
            count=count+1
                
            if fs_c in ['yes']:
                #Image panels(bottom)**********
                #determine vertices of panel (order of vertices changed to reverse normal)**********
                v3=np.array([x[j],y[i],-z_bp])
                v2=np.array([x[j+1],y[i],-z_bp])
                v1=np.array([x[j+1],y[i+1],-z_bp])
                v4=np.array([x[j],y[i+1],-z_bp])
                            
                #array of panel vertices**********
                verti[counti]=[v1,v2,v3,v4]
                counti=counti+1
    #front panels**********
    for i in range(len(z)-1):
        for j in range(len(y)-1):
            #Source panels(front)**********
            #determine vertices of source panel**********
            v1=np.array([L/2,y[j],z[i]])
            v2=np.array([L/2,y[j],z[i+1]])
            v3=np.array([L/2,y[j+1],z[i+1]])
            v4=np.array([L/2,y[j+1],z[i]])
                
            #array of panel vertices**********
            vert[count]=([v1,v2,v3,v4])
            count=count+1
                
            if fs_c in ['yes']:    
                #Image panels(front)**********
                #detremine vertices of panel**********
                v3=np.array([L/2,y[j],-z[i]])
                v2=np.array([L/2,y[j],-z[i+1]])
                v1=np.array([L/2,y[j+1],-z[i+1]])
                v4=np.array([L/2,y[j+1],-z[i]])
                    
                #array of panel vertices**********
                verti[counti]=[v1,v2,v3,v4]
                counti=counti+1
        
    #rear panels**********
    for i in range(len(z)-1):
        for j in range(len(y)-1):
            #Source panels(rear)**********
            #determine vertices of source panel**********
            v1=np.array([-L/2,y[j],z[i]])
            v2=np.array([-L/2,y[j+1],z[i]])
            v3=np.array([-L/2,y[j+1],z[i+1]])
            v4=np.array([-L/2,y[j],z[i+1]])
                
            #array of panel vertices**********
            vert[count]=[v1,v2,v3,v4]
            count=count+1
                
            if fs_c in ['yes']:    
                #Image panels(rear)**********
                #detremine vertices of panel**********
                v3=np.array([-L/2,y[j],-z[i]])
                v2=np.array([-L/2,y[j+1],-z[i]])
                v1=np.array([-L/2,y[j+1],-z[i+1]])
                v4=np.array([-L/2,y[j],-z[i+1]])
                    
                #array of panel vertices**********
                verti[counti]=[v1,v2,v3,v4]
                counti=counti+1
                    
    #port panels**********
    for i in range(len(z)-1):
        for j in range(len(x)-1):
            #Source panels(port)**********
            #determine vertices of source panel**********
            v1=np.array([x[j],B/2,z[i]])
            v4=np.array([x[j],B/2,z[i+1]])
            v3=np.array([x[j+1],B/2,z[i+1]])
            v2=np.array([x[j+1],B/2,z[i]])
                
            #array of panel vertices**********
            vert[count]=[v1,v2,v3,v4]
            count=count+1
                
            if fs_c in ['yes']:    
                #Image panels(rear)**********
                #detremine vertices of panel**********
                v3=np.array([x[j],B/2,-z[i]])
                v4=np.array([x[j],B/2,-z[i+1]])
                v1=np.array([x[j+1],B/2,-z[i+1]])
                v2=np.array([x[j+1],B/2,-z[i]])
                
                #array of panel vertices**********
                verti[counti]=[v1,v2,v3,v4]
                counti=counti+1
        
    #stbd panels**********
    for i in range(len(z)-1):
        for j in range(len(x)-1):
            #Source panels(stbd)**********
            #determine vertices of source panel**********
            v1=np.array([x[j],-B/2,z[i]])
            v2=np.array([x[j],-B/2,z[i+1]])
            v3=np.array([x[j+1],-B/2,z[i+1]])
            v4=np.array([x[j+1],-B/2,z[i]])
                
            #array of panel vertices**********
            vert[count]=[v1,v2,v3,v4]
            count=count+1
                
            if fs_c in ['yes']:
                #Image panels(rear)**********
                #detremine vertices of panel**********
                v3=np.array([x[j],-B/2,-z[i]])
                v2=np.array([x[j],-B/2,-z[i+1]])
                v1=np.array([x[j+1],-B/2,-z[i+1]])
                v4=np.array([x[j+1],-B/2,-z[i]])
                    
                #array of panel vertices**********
                verti[counti]=[v1,v2,v3,v4]
                counti=counti+1
            
    if b_c in ['submerged']:
        #top panels**********
        for i in range(len(y)-1):
            for j in range(len(x)-1):
                #Source panels(stbd)**********
                #determine vertices of source panel**********
                v1=np.array([x[j],y[i],z_tp])
                v2=np.array([x[j],y[i+1],z_tp])
                v3=np.array([x[j+1],y[i+1],z_tp])
                v4=np.array([x[j+1],y[i],z_tp])
                    
                #array of panel vertices**********
                vert[count]=[v1,v2,v3,v4]
                count=count+1
                    
                if fs_c in ['yes']:    
                    #Image panels(top)**********
                    #detremine vertices of panel**********
                    v3=np.array([x[j],y[i],-z_tp])
                    v2=np.array([x[j],y[i+1],-z_tp])
                    v1=np.array([x[j+1],y[i+1],-z_tp])
                    v4=np.array([x[j+1],y[i],-z_tp])
                        
                    #array of panel vertices**********
                    verti[counti]=[v1,v2,v3,v4]
                    counti=counti+1
    return(vert,verti,z_bp,z_tp)

#***************************************************************************************************
def panel_par(v1,v2,v3,v4,coldist):
    "Determines the outward unit normal, centroid, tangent unit vectors for a quadrilateral panel"
    #determine diagonals
    D1=v3-v1
    D2=v4-v2
    #determine surface normals
    N=np.cross(D2,D1)
    n=N/np.linalg.norm(N)
    #determine tangent vectors
    L=(v4+v3)/2-(v1+v2)/2
    l=L/np.linalg.norm(L)
    P=np.cross(n,l)
    p=P/np.linalg.norm(P)
    #determine centroid
    d1=np.sqrt(np.sum((v2-v1)**2))
    d2=np.sqrt(np.sum((v3-v2)**2))
    d3=np.sqrt(np.sum((v4-v3)**2))
    d4=np.sqrt(np.sum((v1-v4)**2))
    d=d1+d2+d3+d4
        
    cx1=(v1[0]+v2[0])/2
    cx2=(v2[0]+v3[0])/2
    cx3=(v3[0]+v4[0])/2
    cx4=(v4[0]+v1[0])/2
        
    cy1=(v1[1]+v2[1])/2
    cy2=(v2[1]+v3[1])/2
    cy3=(v3[1]+v4[1])/2
    cy4=(v4[1]+v1[1])/2
        
    cz1=(v1[2]+v2[2])/2
    cz2=(v2[2]+v3[2])/2
    cz3=(v3[2]+v4[2])/2
    cz4=(v4[2]+v1[2])/2
        
    c=(np.array([(cx1*d1+cx2*d2+cx3*d3+cx4*d4)/(d1+d2+d3+d4), (cy1*d1+cy2*d2+cy3*d3+cy4*d4)/(d1+d2+d3+d4),
                     (cz1*d1+cz2*d2+cz3*d3+cz4*d4)/(d1+d2+d3+d4)]))
    cp=np.array([c[0]-coldist*n[0],c[1]-coldist*n[1],c[2]-coldist*n[2]])
    #panel vertices in local co-ordinates
    v1lx=(v1[0]-c[0])*l[0]+(v1[1]-c[1])*l[1]+(v1[2]-c[2])*l[2]
    v1ly=(v1[0]-c[0])*p[0]+(v1[1]-c[1])*p[1]+(v1[2]-c[2])*p[2]
    
    v2lx=(v2[0]-c[0])*l[0]+(v2[1]-c[1])*l[1]+(v2[2]-c[2])*l[2]
    v2ly=(v2[0]-c[0])*p[0]+(v2[1]-c[1])*p[1]+(v2[2]-c[2])*p[2]
    
    v3lx=(v3[0]-c[0])*l[0]+(v3[1]-c[1])*l[1]+(v3[2]-c[2])*l[2]
    v3ly=(v3[0]-c[0])*p[0]+(v3[1]-c[1])*p[1]+(v3[2]-c[2])*p[2]
    
    v4lx=(v4[0]-c[0])*l[0]+(v4[1]-c[1])*l[1]+(v4[2]-c[2])*l[2]
    v4ly=(v4[0]-c[0])*p[0]+(v4[1]-c[1])*p[1]+(v4[2]-c[2])*p[2]
    
    return D1,D2,n,l,p,c,v1lx,v1ly,v2lx,v2ly,v3lx,v3ly,v4lx,v4ly,cp

#***************************************************************************************************
def hydrostatics(pan,b_c,rho,g,ndL1,z_cg):
    "function to calculate the hydrostatics of a body given its panel parameters and other inputs"
    #Volume Calculation**********
    sub_vol_x=0 #initialize variable to hold the submerged volume data calculated using x projection of panels
    sub_vol_y=0 #initialize variable to hold the submerged volume data calculated using y projection of panels
    sub_vol_z=0 #initialize variable to hold the submerged volume data calculated using z projection of panels

    z_cb1=0 #initialize variable to hold intermediate value to calculate z coord. of centre of buoyancy
    x_cb1=0 #initialize variabe to hold intermediate value to calculate x coord. of centre of buoyancy
    A_wp=0 #initialize variable to hold waterplane area
    x_wp1=0 #initialize variable to hold x coordinate of water plane area centroid
    I_wp_xx=0 #initialize variable to hold moment of water plane area about x axis
    I_wp_yy=0 #initialze variable to hold moment of water plane areas about y axis
    
    pan_area=np.zeros(len(pan)) #initialize vector to hold panel area data
    for i in range(len(pan)):
        #calculate panel area
        #-ve sign when vertices are taken in clockwise direction when viewed from outward normal
        pan_area[i]=-0.5*((pan[i][5][0]*pan[i][6][1]+pan[i][6][0]*pan[i][7][1]+pan[i][7][0]*pan[i][8][1]+pan[i][8][0]*pan[i][5][1])
             -(pan[i][6][0]*pan[i][5][1]+pan[i][7][0]*pan[i][6][1]+pan[i][8][0]*pan[i][7][1]+pan[i][5][0]*pan[i][8][1]))
        pan_vol_x=pan_area[i]*pan[i][1][0]*pan[i][2][0]
        pan_vol_y=pan_area[i]*pan[i][1][1]*pan[i][2][1]
        pan_vol_z=pan_area[i]*pan[i][1][2]*pan[i][2][2]
        
        #calculate volumes in three directions to cross check
        sub_vol_x=sub_vol_x+pan_vol_x
        sub_vol_y=sub_vol_y+pan_vol_y
        sub_vol_z=sub_vol_z+pan_vol_z
        
        sub_vol=sub_vol_z
        
        if b_c in ['floating']:
            sub_vol=sub_vol_z
        
            #calculate centre of buoyancy z position w.r.t origin for each panel
            pan_vol_zcb=pan_area[i]*pan[i][2][2]*0.5*np.square(pan[i][1][2])
            z_cb1=z_cb1+pan_vol_zcb
            
            #calculate cerntre of buoyancy x position w.r.t origin for each panel
            pan_vol_xcb=pan_area[i]*pan[i][2][2]*pan[i][1][2]*pan[i][1][0]
            x_cb1=x_cb1+pan_vol_xcb
            
            #calculate water plane area
            A_wp=A_wp-pan_area[i]*pan[i][2][2]
            
            #loop variable for holding sum of values to calculate long. centre of floatation
            x_wp1=x_wp1-pan_area[i]*pan[i][2][2]*pan[i][1][0]
            
            #calculate moment of water plane area about x-axis
            I_wp_xx=I_wp_xx-pan_area[i]*pan[i][2][2]*np.square(pan[i][1][1])
            
            #calculate moment of water plane area about y-axis
            I_wp_yy=I_wp_yy-pan_area[i]*pan[i][2][2]*np.square(pan[i][1][0])
        

            z_cb=z_cb1/sub_vol #vertical centre of buoyancy
            x_cb=x_cb1/sub_vol #longitudinal centre of buoyancy 
            x_wp=x_wp1/A_wp    #longitudinal centre of floatation

            #non dimensionalized hydrostatic coefficients
            C_33=rho*g*A_wp/(rho*g*ndL1*ndL1)
            C_35=-C_33*x_wp/(rho*g*ndL1*ndL1*ndL1)
            C_44=rho*g*(sub_vol*(z_cb-z_cg)+I_wp_xx)/(rho*g*ndL1*ndL1*ndL1*ndL1)
            C_53=C_35
            C_55=rho*g*(sub_vol*(z_cb-z_cg)+I_wp_yy)/(rho*g*ndL1*ndL1*ndL1*ndL1)
    
    print('****SUBMERGED VOLUME****','\n','sub_vol_x= ',sub_vol_x,'\n','sub_vol_y= ',sub_vol_y,'\n',
            'sub_vol_z= ',sub_vol_z,'\n')

    if b_c in ['floating']:

        print('****HYDROSTATICS****','\n','z_cb= ',z_cb,'\n','x_cb= ',x_cb,'\n','x_wp= ',x_wp,'\n',
            'C_33= ',C_33,'\n','C_35= ',C_35,'\n','C_44= ',C_44,'\n','C_53= ',C_53,'\n','C_55= ',C_55)
    return(pan_area)
    

#****************************************************************************************************
def non_wav_green_func(pan,pani,fs_c):
    "function to calculate the non wavy part of the Green function based on Hess & Smith/ Katz & Plotkin method"
    iv=np.zeros((len(pan),len(pan)),dtype=np.ndarray)# initialize vector to store directional derivatives of induced velocities at null point of panel 'i'
                                            #due to unit density source distribiution over panel 'j' 
    ivi=np.zeros((len(pan),len(pan)),dtype=np.ndarray)# initialize vector to store directional derivatives of induced velocities at null point of panel 'i'
                                            #due to unit density source distribiution over image panel 'j' 
    
    dnr=np.zeros((len(pan),len(pan)))# initialize vector to store normal derivative of induced velocities at null point of panel 'i'
                                            #due to unit density source distribiution over panel 'j' 
    r_inv=np.zeros((len(pan),len(pan)))# initial vector to store the velocity potential at null point of panel 'i'
                                            #due to unit density source distribution over panel 'j'
    dnri=np.zeros((len(pan),len(pan)))# initialize vector to store normal derivative of induced velocities at null point of panel 'i'
                                            #due to unit density source distribiution over image panel 'j' 
    ri_inv=np.zeros((len(pan),len(pan)))# initial vector to store the velocity potential at null point of panel 'i'
                                            #due to unit density source distribution over image panel 'j'
    
    for i in range(len(pan)):
        for j in range(len(pan)):
            
            #calculation of the coordinate of the centroid of the i th panel in the LCS (origin at col. point) of the j th source panel
            distx=pan[i][1][0]-pan[j][9][0]
            disty=pan[i][1][1]-pan[j][9][1]
            distz=pan[i][1][2]-pan[j][9][2]
            cplx=distx*pan[j][3][0]+disty*pan[j][3][1]+distz*pan[j][3][2]
            cply=distx*pan[j][4][0]+disty*pan[j][4][1]+distz*pan[j][4][2]
            cplz=distx*pan[j][2][0]+disty*pan[j][2][1]+distz*pan[j][2][2]
           
            #calculation of d,m,r,h
            
            d12=np.sqrt((pan[j][6][0]-pan[j][5][0])*(pan[j][6][0]-pan[j][5][0])
                        +(pan[j][6][1]-pan[j][5][1])*(pan[j][6][1]-pan[j][5][1]))
            
            d23=np.sqrt((pan[j][7][0]-pan[j][6][0])*(pan[j][7][0]-pan[j][6][0])
                        +(pan[j][7][1]-pan[j][6][1])*(pan[j][7][1]-pan[j][6][1]))
            
            d34=np.sqrt((pan[j][8][0]-pan[j][7][0])*(pan[j][8][0]-pan[j][7][0])
                        +(pan[j][8][1]-pan[j][7][1])*(pan[j][8][1]-pan[j][7][1]))
            
            d41=np.sqrt((pan[j][5][0]-pan[j][8][0])*(pan[j][5][0]-pan[j][8][0])
                        +(pan[j][5][1]-pan[j][8][1])*(pan[j][5][1]-pan[j][8][1]))
            
            #calculate correct sign of vertical slopes
            
            #calculate m12
            if abs(pan[j][6][0]-pan[j][5][0])<0.000001:
                if (pan[j][6][1]-pan[j][5][1])>0:
                    m12=np.inf
                elif (pan[j][6][1]-pan[j][5][1])<0:
                    m12=-np.inf
            elif abs(pan[j][6][1]-pan[j][5][1])<0.000001:
                if (pan[j][6][0]-pan[j][5][0])>0:
                    m12=0
                elif (pan[j][6][0]-pan[j][5][0])<0:
                    m12=0
            else:
                m12=(pan[j][6][1]-pan[j][5][1])/(pan[j][6][0]-pan[j][5][0])
            
            #calculate m23
            if abs(pan[j][7][0]-pan[j][6][0])<0.000001:
                if (pan[j][7][1]-pan[j][6][1])>0:
                    m23=np.inf
                elif (pan[j][7][1]-pan[j][6][1])<0:
                    m23=-np.inf
            elif abs(pan[j][7][1]-pan[j][6][1])<0.000001:
                if (pan[j][7][0]-pan[j][6][0])>0:
                    m23=0
                elif (pan[j][7][0]-pan[j][6][0])<0:
                    m23=0
            else:
                m23=(pan[j][7][1]-pan[j][6][1])/(pan[j][7][0]-pan[j][6][0])
            
            #calculate m34
            if abs(pan[j][8][0]-pan[j][7][0])<0.000001:
                if (pan[j][8][1]-pan[j][7][1])>0:
                    m34=np.inf
                elif (pan[j][8][1]-pan[j][7][1])<0:
                    m34=-np.inf
            elif abs(pan[j][8][1]-pan[j][7][1])<0.000001:
                if (pan[j][8][0]-pan[j][7][0])>0:
                    m34=0
                elif (pan[j][8][0]-pan[j][7][0])<0:
                    m34=0
            else:
                m34=(pan[j][8][1]-pan[j][7][1])/(pan[j][8][0]-pan[j][7][0])
            
            
             #calculate m41
            if abs(pan[j][5][0]-pan[j][8][0])<0.000001:
                if (pan[j][5][1]-pan[j][8][1])>0:
                    m41=np.inf
                elif (pan[j][5][1]-pan[j][8][1])<0:
                    m41=-np.inf
            elif abs(pan[j][5][1]-pan[j][8][1])<0.000001:
                if (pan[j][5][0]-pan[j][8][0])>0:
                    m41=0
                elif (pan[j][5][0]-pan[j][8][0])<0:
                    m41=0
            else:
                m41=(pan[j][5][1]-pan[j][8][1])/(pan[j][5][0]-pan[j][8][0])
            
            r1=np.sqrt((cplx-pan[j][5][0])*(cplx-pan[j][5][0])+(cply-pan[j][5][1])*(cply-pan[j][5][1])+cplz*cplz)
            r2=np.sqrt((cplx-pan[j][6][0])*(cplx-pan[j][6][0])+(cply-pan[j][6][1])*(cply-pan[j][6][1])+cplz*cplz)
            r3=np.sqrt((cplx-pan[j][7][0])*(cplx-pan[j][7][0])+(cply-pan[j][7][1])*(cply-pan[j][7][1])+cplz*cplz)
            r4=np.sqrt((cplx-pan[j][8][0])*(cplx-pan[j][8][0])+(cply-pan[j][8][1])*(cply-pan[j][8][1])+cplz*cplz)
            
            
            e1=(cplx-pan[j][5][0])*(cplx-pan[j][5][0])+cplz*cplz
            e2=(cplx-pan[j][6][0])*(cplx-pan[j][6][0])+cplz*cplz
            e3=(cplx-pan[j][7][0])*(cplx-pan[j][7][0])+cplz*cplz
            e4=(cplx-pan[j][8][0])*(cplx-pan[j][8][0])+cplz*cplz
            
            h1=(cply-pan[j][5][1])*(cplx-pan[j][5][0])
            h2=(cply-pan[j][6][1])*(cplx-pan[j][6][0])
            h3=(cply-pan[j][7][1])*(cplx-pan[j][7][0])
            h4=(cply-pan[j][8][1])*(cplx-pan[j][8][0])
            
            #derivative components in LCS of source panel
            
            rx=((pan[j][6][1]-pan[j][5][1])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                +(pan[j][7][1]-pan[j][6][1])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                +(pan[j][8][1]-pan[j][7][1])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                +(pan[j][5][1]-pan[j][8][1])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
            
            ry=((pan[j][5][0]-pan[j][6][0])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                +(pan[j][6][0]-pan[j][7][0])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                +(pan[j][7][0]-pan[j][8][0])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                +(pan[j][8][0]-pan[j][5][0])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
            
            rz=(np.arctan((m12*e1-h1)/(cplz*r1))-np.arctan((m12*e2-h2)/(cplz*r2))
                 +np.arctan((m23*e2-h2)/(cplz*r2))-np.arctan((m23*e3-h3)/(cplz*r3))
                 +np.arctan((m34*e3-h3)/(cplz*r3))-np.arctan((m34*e4-h4)/(cplz*r4))
                 +np.arctan((m41*e4-h4)/(cplz*r4))-np.arctan((m41*e1-h1)/(cplz*r1)))
            
            #derivative components in UCS
            
            rxx=rx*np.dot(pan[j][3],[1.0,0.0,0.0])
            rxy=rx*np.dot(pan[j][3],[0.0,1.0,0.0])
            rxz=rx*np.dot(pan[j][3],[0.0,0.0,1.0])
            
            ryx=ry*np.dot(pan[j][4],[1.0,0.0,0.0])
            ryy=ry*np.dot(pan[j][4],[0.0,1.0,0.0])
            ryz=ry*np.dot(pan[j][4],[0.0,0.0,1.0])
            
            rzx=rz*np.dot(pan[j][2],[1.0,0.0,0.0])
            rzy=rz*np.dot(pan[j][2],[0.0,1.0,0.0])
            rzz=rz*np.dot(pan[j][2],[0.0,0.0,1.0])
            
            # surface integral of par.(d/dn)(1/r) over the jth source panel at the centroid of the ith panel (GCS)
            iv[i][j]=[1/(4*np.pi)*(rxx+ryx+rzx),1/(4*np.pi)*(rxy+ryy+rzy),1/(4*np.pi)*(rxz+ryz+rzz)]
            ivi[i][j]=[0,0,0]
            
            #nr=((rxx+ryx+rzx)*pan[i][2][0]+(rxy+ryy+rzy)*pan[i][2][1]+(rxz+ryz+rzz)*pan[i][2][2])
            dnr[i][j]=np.dot(iv[i][j],pan[i][2])
            
            
            #surface integral of (1/r) over the jth source panel at the centroid of the ith panel
            r_inv[i][j]=-1/(4*np.pi)*((((cplx-pan[j][5][0])*(pan[j][6][1]-pan[j][5][1])-(cply-pan[j][5][1])*(pan[j][6][0]-pan[j][5][0]))/d12
                                        *math.log((r1+r2+d12)/(r1+r2-d12))
                                        +((cplx-pan[j][6][0])*(pan[j][7][1]-pan[j][6][1])-(cply-pan[j][6][1])*(pan[j][7][0]-pan[j][6][0]))/d23
                                        *math.log((r2+r3+d23)/(r2+r3-d23))
                                        +((cplx-pan[j][7][0])*(pan[j][8][1]-pan[j][7][1])-(cply-pan[j][7][1])*(pan[j][8][0]-pan[j][7][0]))/d34
                                        *math.log((r3+r4+d34)/(r3+r4-d34))
                                        +((cplx-pan[j][8][0])*(pan[j][5][1]-pan[j][8][1])-(cply-pan[j][8][1])*(pan[j][5][0]-pan[j][8][0]))/d41
                                        *math.log((r4+r1+d41)/(r4+r1-d41))-cplz*rz))    
           
            if fs_c in ['yes']:
                #calculation of the coordinate of the centroid of the i th panel in the LCS of the j th image panel
                distx=pan[i][1][0]-pani[j][9][0]
                disty=pan[i][1][1]-pani[j][9][1]
                distz=pan[i][1][2]-pani[j][9][2]
                cplx=distx*pani[j][3][0]+disty*pani[j][3][1]+distz*pani[j][3][2]
                cply=distx*pani[j][4][0]+disty*pani[j][4][1]+distz*pani[j][4][2]
                cplz=distx*pani[j][2][0]+disty*pani[j][2][1]+distz*pani[j][2][2]
               
                #calculation of d,m,r,h
                
                d12=np.sqrt((pani[j][6][0]-pani[j][5][0])*(pani[j][6][0]-pani[j][5][0])
                            +(pani[j][6][1]-pani[j][5][1])*(pani[j][6][1]-pani[j][5][1]))
                
                d23=np.sqrt((pani[j][7][0]-pani[j][6][0])*(pani[j][7][0]-pani[j][6][0])
                            +(pani[j][7][1]-pani[j][6][1])*(pani[j][7][1]-pani[j][6][1]))
                
                d34=np.sqrt((pani[j][8][0]-pani[j][7][0])*(pani[j][8][0]-pani[j][7][0])
                            +(pani[j][8][1]-pani[j][7][1])*(pani[j][8][1]-pani[j][7][1]))
                
                d41=np.sqrt((pani[j][5][0]-pani[j][8][0])*(pani[j][5][0]-pani[j][8][0])
                            +(pani[j][5][1]-pani[j][8][1])*(pani[j][5][1]-pani[j][8][1]))
                
                #calculate m12
                if abs(pan[j][6][0]-pan[j][5][0])<0.000001:
                    if (pan[j][6][1]-pan[j][5][1])>0:
                        m12=np.inf
                    elif (pan[j][6][1]-pan[j][5][1])<0:
                        m12=-np.inf
                elif abs(pan[j][6][1]-pan[j][5][1])<0.000001:
                    if (pan[j][6][0]-pan[j][5][0])>0:
                        m12=0
                    elif (pan[j][6][0]-pan[j][5][0])<0:
                        m12=0
                else:
                    m12=(pan[j][6][1]-pan[j][5][1])/(pan[j][6][0]-pan[j][5][0])
                
                #calculate m23
                if abs(pan[j][7][0]-pan[j][6][0])<0.000001:
                    if (pan[j][7][1]-pan[j][6][1])>0:
                        m23=np.inf
                    elif (pan[j][7][1]-pan[j][6][1])<0:
                        m23=-np.inf
                elif abs(pan[j][7][1]-pan[j][6][1])<0.000001:
                    if (pan[j][7][0]-pan[j][6][0])>0:
                        m23=0
                    elif (pan[j][7][0]-pan[j][6][0])<0:
                        m23=0
                else:
                    m23=(pan[j][7][1]-pan[j][6][1])/(pan[j][7][0]-pan[j][6][0])
                
                #calculate m34
                if abs(pan[j][8][0]-pan[j][7][0])<0.000001:
                    if (pan[j][8][1]-pan[j][7][1])>0:
                        m34=np.inf
                    elif (pan[j][8][1]-pan[j][7][1])<0:
                        m34=-np.inf
                elif abs(pan[j][8][1]-pan[j][7][1])<0.000001:
                    if (pan[j][8][0]-pan[j][7][0])>0:
                        m34=0
                    elif (pan[j][8][0]-pan[j][7][0])<0:
                        m34=0
                else:
                    m34=(pan[j][8][1]-pan[j][7][1])/(pan[j][8][0]-pan[j][7][0])
                
                
                 #calculate m41
                if abs(pan[j][5][0]-pan[j][8][0])<0.000001:
                    if (pan[j][5][1]-pan[j][8][1])>0:
                        m41=np.inf
                    elif (pan[j][5][1]-pan[j][8][1])<0:
                        m41=-np.inf
                elif abs(pan[j][5][1]-pan[j][8][1])<0.000001:
                    if (pan[j][5][0]-pan[j][8][0])>0:
                        m41=0
                    elif (pan[j][5][0]-pan[j][8][0])<0:
                        m41=0
                else:
                    m41=(pan[j][5][1]-pan[j][8][1])/(pan[j][5][0]-pan[j][8][0])
                    
                r1=np.sqrt((cplx-pani[j][5][0])*(cplx-pani[j][5][0])+(cply-pani[j][5][1])*(cply-pani[j][5][1])+cplz*cplz)
                r2=np.sqrt((cplx-pani[j][6][0])*(cplx-pani[j][6][0])+(cply-pani[j][6][1])*(cply-pani[j][6][1])+cplz*cplz)
                r3=np.sqrt((cplx-pani[j][7][0])*(cplx-pani[j][7][0])+(cply-pani[j][7][1])*(cply-pani[j][7][1])+cplz*cplz)
                r4=np.sqrt((cplx-pani[j][8][0])*(cplx-pani[j][8][0])+(cply-pani[j][8][1])*(cply-pani[j][8][1])+cplz*cplz)
                
                
                e1=(cplx-pani[j][5][0])*(cplx-pani[j][5][0])+cplz*cplz
                e2=(cplx-pani[j][6][0])*(cplx-pani[j][6][0])+cplz*cplz
                e3=(cplx-pani[j][7][0])*(cplx-pani[j][7][0])+cplz*cplz
                e4=(cplx-pani[j][8][0])*(cplx-pani[j][8][0])+cplz*cplz
                
                h1=(cply-pani[j][5][1])*(cplx-pani[j][5][0])
                h2=(cply-pani[j][6][1])*(cplx-pani[j][6][0])
                h3=(cply-pani[j][7][1])*(cplx-pani[j][7][0])
                h4=(cply-pani[j][8][1])*(cplx-pani[j][8][0])
                
                #derivative components in LCS of source panel
                
                rx=((pani[j][6][1]-pani[j][5][1])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                    +(pani[j][7][1]-pani[j][6][1])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                    +(pani[j][8][1]-pani[j][7][1])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                    +(pani[j][5][1]-pani[j][8][1])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
                
                ry=((pani[j][5][0]-pani[j][6][0])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                    +(pani[j][6][0]-pani[j][7][0])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                    +(pani[j][7][0]-pani[j][8][0])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                    +(pani[j][8][0]-pani[j][5][0])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
                
                rz=(np.arctan((m12*e1-h1)/(cplz*r1))-np.arctan((m12*e2-h2)/(cplz*r2))
                     +np.arctan((m23*e2-h2)/(cplz*r2))-np.arctan((m23*e3-h3)/(cplz*r3))
                     +np.arctan((m34*e3-h3)/(cplz*r3))-np.arctan((m34*e4-h4)/(cplz*r4))
                     +np.arctan((m41*e4-h4)/(cplz*r4))-np.arctan((m41*e1-h1)/(cplz*r1)))
                
                #derivative components in UCS
                
                rxx=rx*np.dot(pani[j][3],[1.0,0.0,0.0])
                rxy=rx*np.dot(pani[j][3],[0.0,1.0,0.0])
                rxz=rx*np.dot(pani[j][3],[0.0,0.0,1.0])
                
                ryx=ry*np.dot(pani[j][4],[1.0,0.0,0.0])
                ryy=ry*np.dot(pani[j][4],[0.0,1.0,0.0])
                ryz=ry*np.dot(pani[j][4],[0.0,0.0,1.0])
                
                rzx=rz*np.dot(pani[j][2],[1.0,0.0,0.0])
                rzy=rz*np.dot(pani[j][2],[0.0,1.0,0.0])
                rzz=rz*np.dot(pani[j][2],[0.0,0.0,1.0])
                
                # surface integral of par.(d/dn)(1/r) over the jth source panel at the centroid of the ith panel (GCS)
                ivi[i][j]=[1/(4*np.pi)*(rxx+ryx+rzx),1/(4*np.pi)*(rxy+ryy+rzy),1/(4*np.pi)*(rxz+ryz+rzz)]
                
                #nr=((rxx+ryx+rzx)*pan[i][2][0]+(rxy+ryy+rzy)*pan[i][2][1]+(rxz+ryz+rzz)*pan[i][2][2])
                dnri[i][j]=np.dot(ivi[i][j],pan[i][2])
                
                ri_inv[i][j]=-1/(4*np.pi)*((((cplx-pani[j][5][0])*(pani[j][6][1]-pani[j][5][1])-(cply-pani[j][5][1])*(pani[j][6][0]-pani[j][5][0]))/d12
                                            *math.log((r1+r2+d12)/(r1+r2-d12))
                                            +((cplx-pani[j][6][0])*(pani[j][7][1]-pani[j][6][1])-(cply-pani[j][6][1])*(pani[j][7][0]-pani[j][6][0]))/d23
                                            *math.log((r2+r3+d23)/(r2+r3-d23))
                                            +((cplx-pani[j][7][0])*(pani[j][8][1]-pani[j][7][1])-(cply-pani[j][7][1])*(pani[j][8][0]-pani[j][7][0]))/d34
                                            *math.log((r3+r4+d34)/(r3+r4-d34))
                                            +((cplx-pani[j][8][0])*(pani[j][5][1]-pani[j][8][1])-(cply-pani[j][8][1])*(pani[j][5][0]-pani[j][8][0]))/d41
                                            *math.log((r4+r1+d41)/(r4+r1-d41))-cplz*rz))
                
    return(dnr,dnri,r_inv,ri_inv,iv,ivi)

#Wavy Green Function
#****************************************************************************************************
def wav_green_func(pan,omega,ndL,g,coldist,pan_area):
    "function to determine the wavy part of the Green's function based on Teleste and Noblesse (1986)"   
    sG0=np.zeros((len(pan),len(pan)),dtype=complex)# initialize matrix to hold the integral of the wavy part of the Green function
    sdG0_n=np.zeros((len(pan),len(pan)),dtype=complex)# initialize matrix to hold the intergral of the normal derivative of the wavy
                                                        #part of the Green function
    f=omega*omega*ndL/g #calculate non-dimesnional frequency
    for i in range(len(pan)): #calculate various non-dimensional values as given in the referenced paper
        for j in range(len(pan)):
            
            rh=np.sqrt((pan[i][1][0]-pan[j][9][0])*(pan[i][1][0]-pan[j][9][0])
                        +(pan[i][1][1]-pan[j][9][1])*(pan[i][1][1]-pan[j][9][1]))/ndL #calculate 'rho' 
            h=f*rh #calculate 'h'
            
            r=np.sqrt(rh*rh+((pan[i][1][2]-pan[j][9][2])*(pan[i][1][2]-pan[j][9][2]))/(ndL*ndL))#calculate 'r'
           
            r1=np.sqrt(rh*rh+((pan[i][1][2]+pan[j][9][2])*(pan[i][1][2]+pan[j][9][2]))/(ndL*ndL))#calculate 'r''
            
            v=f*(pan[i][1][2]+pan[j][9][2])/ndL#calculate 'v'
            
            d=f*r1#calculate 'd'
           
            R0,R1=gradif.gradif(h,v)#calculate 'R0' and 'R1' by using the fortran code patched to Python using F2PY
            G0=2*f*(R0-complex(0,1)*np.pi*scisp.j0(h)*np.exp(v))#calculate the wavy part of the Green function
            
            dG0_rh=2*f*f*(R1-complex(0,1)*np.pi*scisp.j1(h)*np.exp(v))#calculate the derivative of the wavy Green function
            
            
            if (abs(rh<=coldist)): #if evaluation point is very close set the directional derivatives to zero else use the formulae
                dG0_ndx=0
                dG0_ndy=0
                dG0_ndz=0
            else:
                dG0_ndx=(pan[i][1][0]-pan[j][9][0])/(ndL*rh)*dG0_rh
                dG0_ndy=(pan[i][1][1]-pan[j][9][1])/(ndL*rh)*dG0_rh
                dG0_ndz=-2*f*f*(1/d+R0-complex(0,1)*np.pi*scisp.j0(h)*np.exp(v))
           
             
            dG0_xyz=(dG0_ndx,dG0_ndy,dG0_ndz)# directional derivative of the wavy Green function
            
            #calculation of the integral of the wavy part of the green function at the collocation point of panel 'i' due to
            #pulsating source denisty of unit amplitude over the surface of panel 'j'
            sG0[i][j]=-1/(4*np.pi)*G0*pan_area[j]
           
            #calculation of integral of normal derivative of wavy part of green function for panels as above
            sdG0_n[i][j]=1/(4*np.pi)*np.dot(dG0_xyz,pan[i][2])*pan_area[j]
    
    return (sG0,sdG0_n)
    
#****************************************************************************************************
def field_point_vel(fp,pan,pani,sigma,L,B,z_bp,z_tp,ps,fs_c):
    "function to calculate induced velocity components at required field points"    
    iv_fp=np.zeros((len(fp),len(pan)),dtype=np.ndarray)#initialize vector of vectors to hold induced velocity components due to body panels with source distribtuion
    ivi_fp=np.zeros((len(fp),len(pan)),dtype=np.ndarray)#initialize vector of vectors to hold induced velocity components due to image panels with source distribtuion
    for i in range (len(fp)):
        for j in range (len(pan)):
           #induced velocites due source panels 
            if (fp[i][0]<=-(L/2+ps) or fp[i][0]>=L/2+ps or  fp[i][1]>=B/2+ps or
                fp[i][1]<=-(B/2+ps) or fp[i][2]>=z_tp+ps or fp[i][2]<=z_bp-ps):
                distx=fp[i][0]-pan[j][9][0]
                disty=fp[i][1]-pan[j][9][1]
                distz=fp[i][2]-pan[j][9][2]
                cplx=distx*pan[j][3][0]+disty*pan[j][3][1]+distz*pan[j][3][2]
                cply=distx*pan[j][4][0]+disty*pan[j][4][1]+distz*pan[j][4][2]
                cplz=distx*pan[j][2][0]+disty*pan[j][2][1]+distz*pan[j][2][2]
           
                #calculation of d,m,r,h
            
                d12=np.sqrt((pan[j][6][0]-pan[j][5][0])*(pan[j][6][0]-pan[j][5][0])
                            +(pan[j][6][1]-pan[j][5][1])*(pan[j][6][1]-pan[j][5][1]))
            
                d23=np.sqrt((pan[j][7][0]-pan[j][6][0])*(pan[j][7][0]-pan[j][6][0])
                            +(pan[j][7][1]-pan[j][6][1])*(pan[j][7][1]-pan[j][6][1]))
            
                d34=np.sqrt((pan[j][8][0]-pan[j][7][0])*(pan[j][8][0]-pan[j][7][0])
                            +(pan[j][8][1]-pan[j][7][1])*(pan[j][8][1]-pan[j][7][1]))
            
                d41=np.sqrt((pan[j][5][0]-pan[j][8][0])*(pan[j][5][0]-pan[j][8][0])
                            +(pan[j][5][1]-pan[j][8][1])*(pan[j][5][1]-pan[j][8][1]))
                
                #calculate m12
                if abs(pan[j][6][0]-pan[j][5][0])<0.000001:
                    if (pan[j][6][1]-pan[j][5][1])>0:
                        m12=np.inf
                    elif (pan[j][6][1]-pan[j][5][1])<0:
                        m12=-np.inf
                elif abs(pan[j][6][1]-pan[j][5][1])<0.000001:
                    if (pan[j][6][0]-pan[j][5][0])>0:
                        m12=0
                    elif (pan[j][6][0]-pan[j][5][0])<0:
                        m12=0
                else:
                    m12=(pan[j][6][1]-pan[j][5][1])/(pan[j][6][0]-pan[j][5][0])
                
                #calculate m23
                if abs(pan[j][7][0]-pan[j][6][0])<0.000001:
                    if (pan[j][7][1]-pan[j][6][1])>0:
                        m23=np.inf
                    elif (pan[j][7][1]-pan[j][6][1])<0:
                        m23=-np.inf
                elif abs(pan[j][7][1]-pan[j][6][1])<0.000001:
                    if (pan[j][7][0]-pan[j][6][0])>0:
                        m23=0
                    elif (pan[j][7][0]-pan[j][6][0])<0:
                        m23=0
                else:
                    m23=(pan[j][7][1]-pan[j][6][1])/(pan[j][7][0]-pan[j][6][0])
                
                #calculate m34
                if abs(pan[j][8][0]-pan[j][7][0])<0.000001:
                    if (pan[j][8][1]-pan[j][7][1])>0:
                        m34=np.inf
                    elif (pan[j][8][1]-pan[j][7][1])<0:
                        m34=-np.inf
                elif abs(pan[j][8][1]-pan[j][7][1])<0.000001:
                    if (pan[j][8][0]-pan[j][7][0])>0:
                        m34=0
                    elif (pan[j][8][0]-pan[j][7][0])<0:
                        m34=0
                else:
                    m34=(pan[j][8][1]-pan[j][7][1])/(pan[j][8][0]-pan[j][7][0])
                
                
                 #calculate m41
                if abs(pan[j][5][0]-pan[j][8][0])<0.000001:
                    if (pan[j][5][1]-pan[j][8][1])>0:
                        m41=np.inf
                    elif (pan[j][5][1]-pan[j][8][1])<0:
                        m41=-np.inf
                elif abs(pan[j][5][1]-pan[j][8][1])<0.000001:
                    if (pan[j][5][0]-pan[j][8][0])>0:
                        m41=0
                    elif (pan[j][5][0]-pan[j][8][0])<0:
                        m41=0
                else:
                    m41=(pan[j][5][1]-pan[j][8][1])/(pan[j][5][0]-pan[j][8][0])
                
                r1=np.sqrt((cplx-pan[j][5][0])*(cplx-pan[j][5][0])+(cply-pan[j][5][1])*(cply-pan[j][5][1])+cplz*cplz)
                r2=np.sqrt((cplx-pan[j][6][0])*(cplx-pan[j][6][0])+(cply-pan[j][6][1])*(cply-pan[j][6][1])+cplz*cplz)
                r3=np.sqrt((cplx-pan[j][7][0])*(cplx-pan[j][7][0])+(cply-pan[j][7][1])*(cply-pan[j][7][1])+cplz*cplz)
                r4=np.sqrt((cplx-pan[j][8][0])*(cplx-pan[j][8][0])+(cply-pan[j][8][1])*(cply-pan[j][8][1])+cplz*cplz)
                
                
                e1=(cplx-pan[j][5][0])*(cplx-pan[j][5][0])+cplz*cplz
                e2=(cplx-pan[j][6][0])*(cplx-pan[j][6][0])+cplz*cplz
                e3=(cplx-pan[j][7][0])*(cplx-pan[j][7][0])+cplz*cplz
                e4=(cplx-pan[j][8][0])*(cplx-pan[j][8][0])+cplz*cplz
                
                h1=(cply-pan[j][5][1])*(cplx-pan[j][5][0])
                h2=(cply-pan[j][6][1])*(cplx-pan[j][6][0])
                h3=(cply-pan[j][7][1])*(cplx-pan[j][7][0])
                h4=(cply-pan[j][8][1])*(cplx-pan[j][8][0])
                
                #derivative components in LCS of source panel
                
                rx=((pan[j][6][1]-pan[j][5][1])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                    +(pan[j][7][1]-pan[j][6][1])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                    +(pan[j][8][1]-pan[j][7][1])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                    +(pan[j][5][1]-pan[j][8][1])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
                
                ry=((pan[j][5][0]-pan[j][6][0])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                    +(pan[j][6][0]-pan[j][7][0])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                    +(pan[j][7][0]-pan[j][8][0])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                    +(pan[j][8][0]-pan[j][5][0])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
                
                rz=(np.arctan((m12*e1-h1)/(cplz*r1))-np.arctan((m12*e2-h2)/(cplz*r2))
                     +np.arctan((m23*e2-h2)/(cplz*r2))-np.arctan((m23*e3-h3)/(cplz*r3))
                     +np.arctan((m34*e3-h3)/(cplz*r3))-np.arctan((m34*e4-h4)/(cplz*r4))
                     +np.arctan((m41*e4-h4)/(cplz*r4))-np.arctan((m41*e1-h1)/(cplz*r1)))
              
                #derivative components in UCS
                
                rxx=rx*np.dot(pan[j][3],[1.0,0.0,0.0])
                rxy=rx*np.dot(pan[j][3],[0.0,1.0,0.0])
                rxz=rx*np.dot(pan[j][3],[0.0,0.0,1.0])
                
                ryx=ry*np.dot(pan[j][4],[1.0,0.0,0.0])
                ryy=ry*np.dot(pan[j][4],[0.0,1.0,0.0])
                ryz=ry*np.dot(pan[j][4],[0.0,0.0,1.0])
                
                rzx=rz*np.dot(pan[j][2],[1.0,0.0,0.0])
                rzy=rz*np.dot(pan[j][2],[0.0,1.0,0.0])
                rzz=rz*np.dot(pan[j][2],[0.0,0.0,1.0])
                
                # surface integral of par.(d/dn)(1/r) over the jth source panel at the ith field point (GCS)
                iv_fp[i][j]=[1/(4*np.pi)*(rxx+ryx+rzx)*sigma[j],1/(4*np.pi)*(rxy+ryy+rzy)*sigma[j],1/(4*np.pi)*(rxz+ryz+rzz)*sigma[j]]
                ivi_fp[i][j]=[0,0,0]
            else:
                iv_fp[i][j]=[0,0,0]
                ivi_fp[i][j]=[0,0,0]
            
            if fs_c in ['yes']:
                
                distx=fp[i][0]-pani[j][9][0]
                disty=fp[i][1]-pani[j][9][1]
                distz=fp[i][2]-pani[j][9][2]
                cplx=distx*pani[j][3][0]+disty*pani[j][3][1]+distz*pani[j][3][2]
                cply=distx*pani[j][4][0]+disty*pani[j][4][1]+distz*pani[j][4][2]
                cplz=distx*pani[j][2][0]+disty*pani[j][2][1]+distz*pani[j][2][2]
           
                #calculation of d,m,r,h
            
                d12=np.sqrt((pani[j][6][0]-pani[j][5][0])*(pani[j][6][0]-pani[j][5][0])
                        +(pani[j][6][1]-pani[j][5][1])*(pani[j][6][1]-pani[j][5][1]))
            
                d23=np.sqrt((pani[j][7][0]-pani[j][6][0])*(pani[j][7][0]-pani[j][6][0])
                            +(pani[j][7][1]-pani[j][6][1])*(pani[j][7][1]-pani[j][6][1]))
                
                d34=np.sqrt((pani[j][8][0]-pani[j][7][0])*(pani[j][8][0]-pani[j][7][0])
                            +(pani[j][8][1]-pani[j][7][1])*(pani[j][8][1]-pani[j][7][1]))
                
                d41=np.sqrt((pani[j][5][0]-pani[j][8][0])*(pani[j][5][0]-pani[j][8][0])
                            +(pani[j][5][1]-pani[j][8][1])*(pani[j][5][1]-pani[j][8][1]))
                
                #calculate m12
                if abs(pan[j][6][0]-pan[j][5][0])<0.000001:
                    if (pan[j][6][1]-pan[j][5][1])>0:
                        m12=np.inf
                    elif (pan[j][6][1]-pan[j][5][1])<0:
                        m12=-np.inf
                elif abs(pan[j][6][1]-pan[j][5][1])<0.000001:
                    if (pan[j][6][0]-pan[j][5][0])>0:
                        m12=0
                    elif (pan[j][6][0]-pan[j][5][0])<0:
                        m12=0
                else:
                    m12=(pan[j][6][1]-pan[j][5][1])/(pan[j][6][0]-pan[j][5][0])
                
                #calculate m23
                if abs(pan[j][7][0]-pan[j][6][0])<0.000001:
                    if (pan[j][7][1]-pan[j][6][1])>0:
                        m23=np.inf
                    elif (pan[j][7][1]-pan[j][6][1])<0:
                        m23=-np.inf
                elif abs(pan[j][7][1]-pan[j][6][1])<0.000001:
                    if (pan[j][7][0]-pan[j][6][0])>0:
                        m23=0
                    elif (pan[j][7][0]-pan[j][6][0])<0:
                        m23=0
                else:
                    m23=(pan[j][7][1]-pan[j][6][1])/(pan[j][7][0]-pan[j][6][0])
                
                #calculate m34
                if abs(pan[j][8][0]-pan[j][7][0])<0.000001:
                    if (pan[j][8][1]-pan[j][7][1])>0:
                        m34=np.inf
                    elif (pan[j][8][1]-pan[j][7][1])<0:
                        m34=-np.inf
                elif abs(pan[j][8][1]-pan[j][7][1])<0.000001:
                    if (pan[j][8][0]-pan[j][7][0])>0:
                        m34=0
                    elif (pan[j][8][0]-pan[j][7][0])<0:
                        m34=0
                else:
                    m34=(pan[j][8][1]-pan[j][7][1])/(pan[j][8][0]-pan[j][7][0])
                
                
                 #calculate m41
                if abs(pan[j][5][0]-pan[j][8][0])<0.000001:
                    if (pan[j][5][1]-pan[j][8][1])>0:
                        m41=np.inf
                    elif (pan[j][5][1]-pan[j][8][1])<0:
                        m41=-np.inf
                elif abs(pan[j][5][1]-pan[j][8][1])<0.000001:
                    if (pan[j][5][0]-pan[j][8][0])>0:
                        m41=0
                    elif (pan[j][5][0]-pan[j][8][0])<0:
                        m41=0
                else:
                    m41=(pan[j][5][1]-pan[j][8][1])/(pan[j][5][0]-pan[j][8][0])
                
                r1=np.sqrt((cplx-pani[j][5][0])*(cplx-pani[j][5][0])+(cply-pani[j][5][1])*(cply-pani[j][5][1])+cplz*cplz)
                r2=np.sqrt((cplx-pani[j][6][0])*(cplx-pani[j][6][0])+(cply-pani[j][6][1])*(cply-pani[j][6][1])+cplz*cplz)
                r3=np.sqrt((cplx-pani[j][7][0])*(cplx-pani[j][7][0])+(cply-pani[j][7][1])*(cply-pani[j][7][1])+cplz*cplz)
                r4=np.sqrt((cplx-pani[j][8][0])*(cplx-pani[j][8][0])+(cply-pani[j][8][1])*(cply-pani[j][8][1])+cplz*cplz)
                
                
                e1=(cplx-pani[j][5][0])*(cplx-pani[j][5][0])+cplz*cplz
                e2=(cplx-pani[j][6][0])*(cplx-pani[j][6][0])+cplz*cplz
                e3=(cplx-pani[j][7][0])*(cplx-pani[j][7][0])+cplz*cplz
                e4=(cplx-pani[j][8][0])*(cplx-pani[j][8][0])+cplz*cplz
                
                h1=(cply-pani[j][5][1])*(cplx-pani[j][5][0])
                h2=(cply-pani[j][6][1])*(cplx-pani[j][6][0])
                h3=(cply-pani[j][7][1])*(cplx-pani[j][7][0])
                h4=(cply-pani[j][8][1])*(cplx-pani[j][8][0])
                
                #derivative components in LCS of source panel
                
                rx=((pani[j][6][1]-pani[j][5][1])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                    +(pani[j][7][1]-pani[j][6][1])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                    +(pani[j][8][1]-pani[j][7][1])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                    +(pani[j][5][1]-pani[j][8][1])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
                
                ry=((pani[j][5][0]-pani[j][6][0])/d12*math.log((r1+r2-d12)/(r1+r2+d12))
                    +(pani[j][6][0]-pani[j][7][0])/d23*math.log((r2+r3-d23)/(r2+r3+d23))
                    +(pani[j][7][0]-pani[j][8][0])/d34*math.log((r3+r4-d34)/(r3+r4+d34))
                    +(pani[j][8][0]-pani[j][5][0])/d41*math.log((r4+r1-d41)/(r4+r1+d41)))
                
                rz=(np.arctan((m12*e1-h1)/(cplz*r1))-np.arctan((m12*e2-h2)/(cplz*r2))
                     +np.arctan((m23*e2-h2)/(cplz*r2))-np.arctan((m23*e3-h3)/(cplz*r3))
                     +np.arctan((m34*e3-h3)/(cplz*r3))-np.arctan((m34*e4-h4)/(cplz*r4))
                     +np.arctan((m41*e4-h4)/(cplz*r4))-np.arctan((m41*e1-h1)/(cplz*r1)))
              
                #derivative components in UCS
                
                rxx=rx*np.dot(pani[j][3],[1.0,0.0,0.0])
                rxy=rx*np.dot(pani[j][3],[0.0,1.0,0.0])
                rxz=rx*np.dot(pani[j][3],[0.0,0.0,1.0])
                
                ryx=ry*np.dot(pani[j][4],[1.0,0.0,0.0])
                ryy=ry*np.dot(pani[j][4],[0.0,1.0,0.0])
                ryz=ry*np.dot(pani[j][4],[0.0,0.0,1.0])
                
                rzx=rz*np.dot(pani[j][2],[1.0,0.0,0.0])
                rzy=rz*np.dot(pani[j][2],[0.0,1.0,0.0])
                rzz=rz*np.dot(pani[j][2],[0.0,0.0,1.0])
                
                # surface integral of par.(d/dn)(1/r) over the jth source panel at the ith field point (GCS)
                ivi_fp[i][j]=[1/(4*np.pi)*(rxx+ryx+rzx)*sigma[j],1/(4*np.pi)*(rxy+ryy+rzy)*sigma[j],1/(4*np.pi)*(rxz+ryz+rzz)*sigma[j]]
    return(iv_fp,ivi_fp)
    
#****************************************************************************************************    