import numpy as np
import diff_3d_obj_func

#Enter environment data
#***************************************************************************************************
rho=1025                                    #density of water in [kg/m^3]
g=9.81                                      #acceleration due to gravity in [m/s^2]
vf=np.array([0,0,0])                        #incident current velocity [vx,vy,vz]
waves='on'                                 #waves ('on'/'off')
omega=np.arange(0.025,1.025,0.025)          #incident wave frequencies in [rad/s]
wav_dir=0                                   #wave direction in degrees

#Body data
#***************************************************************************************************
geom='cuboidal'                             #select geometry(only'cuboidal' defined as of now)
L=15                                        #length in [m]
B=10                                      #breadth in  [m]
H=10                                       #heignt in [m]
b_c='floating'                             #body condition ('submerged'/'floating')
fs_c='yes'                                  #free surface condition('yes'/'no', if submerged body)
imm_d=5.5                                     #immersion depth of centroid of body, if submerged body)
draft=5                                    #draft, if floating body
z_cg=3                                      #VCG from free surface

#Panel data
#***************************************************************************************************
ps=2.5                                    #panel size
coldist=0.000001                            #distance of source from panel surface (collocation
                                                                                    #distance)

#Degress of freedom
#***************************************************************************************************
surge='no'                                  #consider surge ('yes'/'no')                                  
sway='yes'                                   #consider sway ('yes'/'no')
heave='no'                                  #consider heave ('yes'/'no')
roll='no'                                   #consider roll ('yes'/'no')
pitch='no'                                 #consider pitch ('yes'/'no')
yaw='no'                                    #consider yaw ('yes'/'no')

#Plot specifications
#***************************************************************************************************
b_disp='yes'                                #display body ('yes'/'no')
i_disp='no'                                 #display image ('yes'/'no')
fs_disp='yes'                               #display free surface mesh ('yes'/'no')
fp_data='yes'                               #is field point data required ('yes'/'no')
plane='xy'                                  #plane to display field point data('xy'/'xz')
n_rad_freq=35                               #index number of radiaiton frequency to plot wavy Green Function graph
sf_rad=50                             #scale factor for plotting velocities due to radiation waves
ndL=1                                       #value for non-dimensionalizing wavy green function parameters
ndL1=1                                     #value for non-dimensionalizing final outputs
xlm=(-L,L)                                #xlim of plot
ylm=(-L,L)                                #ylim of plot
zlm=(-L,L)                                #zlim of plot
norm='no'                                   #plot surface normals? 'yes'/'no'
diag='no'                                   #plot surface diagonals? 'yes'/'no'
source='no'                                 #plot sources? 'yes'/'no'
source_str='no'                            #plot source strength? 'yes'/'no'

#***************************************************************************************************
#Do not change data below***************************************************************************
#***************************************************************************************************
print('Control to hydrodynamics master function')

diff_3d_obj_func.Hyd_mstr(ps,coldist,b_c,fs_c,z_cg,rho,g,waves,omega,wav_dir,geom,fp_data,plane,xlm,ylm,zlm,b_disp,
                          i_disp,fs_disp,n_rad_freq,sf_rad,vf,L,B,H,draft,imm_d,ndL,ndL1,norm,diag,
                          source,surge,sway,heave,roll,pitch,yaw,source_str)

print('Program execution completed')
#***************************************************************************************************
#***************************************************************************************************


