import numpy as np
import matplotlib.pyplot as plt
import csv

#function to read the length of the file
def file_len(fname):
    with open(fname) as f:
        for i, l in enumerate(f):
            pass
    return i + 1

#Step 1: Open the data file
fname='am.txt' #specify name of file to open 
lof=file_len(fname) #determine the length of the file

#Step 2: Specify required values to be plotted
i=3 #specify i in a_ij /b_ij
j=3 #specify j in a_ij /b_ij
exf_dir=3 #specify direction of excitation force to plot

#Step 3: Plot non dimensional/ dimensional values?
nd='no' #plot non dimensional values? ('yes' / 'no')
plot_file='yes' #generate plot file for plotting values?

#Step 4: Specify non dimensionalizing parameters
ndL=40 #specify non dimensionalizing length
rho=1025 #specify water density
g=9.81 #specify value of acceleration of gravity

#
nomega=int((lof-18)/22)
omega=np.zeros(nomega)
a=np.zeros(nomega)
b=np.zeros(nomega)
a_nd=np.zeros(nomega)
b_nd=np.zeros(nomega)
exf=np.zeros(nomega)
exf_nd=np.zeros(nomega)
omega_nd=np.zeros(nomega)


il=i-1
jl=j-1
   
if (il==0 and jl==0) or (il==1 and jl==1) or (il==2 and jl==2):
    pf=3
                    
if (il in [0,1,2] and jl in [3,4,5]) or (il in [3,4,5] and jl in [0,1,2]):
    pf=4
                        
if (il==3 and jl==3) or (il==4 and jl==4) or (il==5 and jl==5):
    pf=5

if exf_dir in [1,2,3]:
    pf1=2

if exf_dir in [4,5,6]:
    pf1=3

for k in range(len(omega)):
    omega[k]=np.loadtxt(fname,skiprows=18+k*22,max_rows=1)
    a[k]=np.loadtxt(fname,skiprows=(19+22*k)+(i-1),max_rows=1,usecols=(j-1))
    b[k]=np.loadtxt(fname,skiprows=(26+22*k)+(i-1),max_rows=1,usecols=(j-1))
    exf[k]=np.loadtxt(fname,skiprows=(33+22*k+(exf_dir-1)),max_rows=1)
    if nd in ['yes']:
        a_nd[k]=a[k]/(rho*ndL**pf)
        b_nd[k]=b[k]/(rho*omega[k]*ndL**pf)
        exf_nd[k]=exf[k]/(rho*g*ndL**pf1)
        omega_nd[k]=omega[k]*np.sqrt(ndL/g)
          
#a_nd=a/(rho*ndL**pf)
#exf_nd=exf/(rho*g*ndL**pf1)
#omega_nd=omega*np.sqrt(ndL/g)
if plot_file in ['yes']:
    with open('plot_file.csv','w', newline='')as file:
        file.truncate(0)
        writer=csv.writer(file)
        writer.writerow(["omega","added_mass","damping","excitation_force"])
        for i in range(len(omega)):
            if nd in ['yes']:
                writer.writerow([omega_nd[i],a_nd[i],b_nd[i],exf_nd[i]])
            else:
                writer.writerow([omega[i],a[i],b[i],exf[i]])
            


plt.figure(1)
if nd in ['yes']:
    plt.plot(omega_nd,a_nd)
else:
    plt.plot(omega,a)

plt.grid(True)

plt.figure(2)
if nd in ['yes']:
    plt.plot(omega_nd,b_nd)
else:
    plt.plot(omega,b)
    
plt.grid(True)

plt.figure(3)
if nd in ['yes']:
    plt.plot(omega_nd,exf_nd)
else:
    plt.plot(omega,exf)
    
plt.grid(True)

plt.show()
